// engine/scorer.js — Core scoring algorithm

function scoreItem(item, ebayData) {
  if (!ebayData || ebayData.avgSoldPrice === 0) return null;

  const { askingPrice, photoCount = 0, descWordCount = 0, daysListed = 0 } = item;
  const { avgSoldPrice, daysToSell, competitorCount } = ebayData;

  // --- Step 1: Real profit calculation ---
  const platformFee = avgSoldPrice * 0.13;
  const postage = getPostageEstimate(item.category);
  const netProfit = avgSoldPrice - askingPrice - platformFee - postage;

  // --- Step 2: Score each dimension ---

  // Profit score (35pts max) — £25+ profit = full marks
  const profitScore = Math.min((netProfit / 25) * 35, 35);

  // Below market score (25pts max) — 25%+ below = full marks
  const belowPct = (avgSoldPrice - askingPrice) / avgSoldPrice;
  const belowMarketScore = Math.min(belowPct * 100, 25);

  // Liquidity score (20pts max) — how fast it sells
  let liquidityScore = 2;
  if (daysToSell < 7)  liquidityScore = 20;
  else if (daysToSell < 14) liquidityScore = 15;
  else if (daysToSell < 30) liquidityScore = 8;

  // Risk score (20pts max, deductions)
  let riskScore = 20;
  if (photoCount < 3)       riskScore -= 8;
  if (descWordCount < 20)   riskScore -= 6;
  if (competitorCount > 10) riskScore -= 4;
  if (daysListed > 14)      riskScore -= 2;
  riskScore = Math.max(riskScore, 0);

  // --- Final score ---
  const totalScore = Math.round(
    profitScore + belowMarketScore + liquidityScore + riskScore
  );

  return {
    score: totalScore,
    netProfit: Math.round(netProfit * 100) / 100,
    avgSoldPrice,
    belowMarketPct: Math.round(belowPct * 100),
    daysToSell,
    verdict: totalScore >= 80 ? 'HOT' : totalScore >= 65 ? 'GOOD' : 'SKIP'
  };
}

function getPostageEstimate(category = '') {
  const cat = category.toLowerCase();
  if (cat.includes('cloth') || cat.includes('fashion')) return 3.50;
  if (cat.includes('electronic') || cat.includes('tech'))  return 5.50;
  if (cat.includes('book'))                                return 2.80;
  return 4.50; // default
}

module.exports = { scoreItem };
