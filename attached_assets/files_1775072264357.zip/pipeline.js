// core/pipeline.js
// Every item goes through this exact sequence
// Never changes — sources and intelligence plug in around it

const ebay    = require('../intelligence/ebay');
const scorer  = require('../intelligence/scorer');
const learner = require('../intelligence/learner');
const settings = require('../config/settings');

// ─── PROCESS SINGLE ITEM ─────────────────────────────────────────────────────
async function processItem(rawItem) {
  try {
    // STAGE 1: Hard filters — instant discard, saves API calls
    if (failsHardFilters(rawItem)) return null;

    // STAGE 2: Clean title for accurate eBay search
    const cleanedTitle = cleanTitle(rawItem.title);
    if (cleanedTitle.length < 3) return null;

    // STAGE 3: Market intelligence from eBay
    const market = await ebay.getSoldData(cleanedTitle);
    if (!market) return null;
    if (market.soldCount < settings.minSoldCount) return null;

    // STAGE 4: Apply learned multipliers (gets smarter over time)
    const adjustedMarket = learner.applyMultipliers(rawItem, market);

    // STAGE 5: Score the deal
    const multipliers = learner.getMultipliers();
    const scoring     = scorer.score(rawItem, adjustedMarket, multipliers);
    if (!scoring || scoring.total < settings.scores.watchlist) return null;

    // STAGE 6: Calculate max bid for auctions
    let maxBid = null;
    if (rawItem.isAuction) {
      maxBid = scorer.calculateMaxBid(
        market.medianSoldPrice,
        rawItem.category
      );
    }

    // STAGE 7: Build final deal object
    const deal = {
      id:        `${rawItem.source}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      ...rawItem,
      ...scoring,
      market,
      maxBid,
      daysToSell: market.daysToSell,
      scannedAt:  new Date().toISOString()
    };

    // STAGE 8: Log prediction for learning engine
    learner.logPrediction(
      deal.id,
      scoring.profit.netProfit,
      market.daysToSell,
      scoring.total
    );

    return deal;
  } catch (err) {
    console.error(`[Pipeline] Error processing "${rawItem.title}":`, err.message);
    return null;
  }
}

// ─── PROCESS BATCH ───────────────────────────────────────────────────────────
async function processBatch(items, delayMs = 600) {
  const results = [];

  for (const item of items) {
    const deal = await processItem(item);
    if (deal) results.push(deal);
    await sleep(delayMs); // respect rate limits
  }

  return results;
}

// ─── HARD FILTERS ────────────────────────────────────────────────────────────
function failsHardFilters(item) {
  if (!item.title || item.title.length < 3)         return true;
  if (!item.askingPrice || item.askingPrice <= 0)   return true;
  if (item.askingPrice > settings.maxAskingPrice)   return true;
  if (item.photoCount === 0)                         return true;

  // Reject bad condition words in title
  const titleLower = item.title.toLowerCase();
  if (settings.rejectWords.some(w => titleLower.includes(w))) return true;

  return false;
}

// ─── TITLE CLEANER ───────────────────────────────────────────────────────────
function cleanTitle(raw) {
  const fillerWords = [
    'bargain', 'stunning', 'amazing', 'wow', 'look', 'grab',
    'must', 'see', 'lol', 'cheap', 'great', 'excellent',
    'beautiful', 'lovely', 'nice', 'fantastic', 'brilliant',
    'quick', 'sale', 'reduced', 'ono', 'offers', 'welcome'
  ];

  let clean = raw
    .toLowerCase()
    .replace(/[^\w\s]/g, ' ')   // remove punctuation
    .replace(/\s+/g, ' ')        // normalise spaces
    .trim();

  // Remove filler words
  fillerWords.forEach(word => {
    clean = clean.replace(new RegExp(`\\b${word}\\b`, 'gi'), '');
  });

  // Capitalise first letter of each word
  clean = clean.replace(/\b\w/g, l => l.toUpperCase());

  return clean.trim().substring(0, 60);
}

const sleep = ms => new Promise(r => setTimeout(r, ms));

module.exports = { processItem, processBatch, cleanTitle, failsHardFilters };
