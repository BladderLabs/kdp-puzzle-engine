// config/settings.js
// ALL settings live here. Change anything without touching other files.

module.exports = {

  // ─── SCANNING ───────────────────────────────────────────
  scanInterval: 20,          // minutes between auto scans
  maxAskingPrice: 500,       // never analyse items above this price
  minNetProfit: 8,           // hard floor — below this, discard
  minROI: 30,                // minimum return on investment %
  minSoldCount: 3,           // item must have sold at least this many times

  // ─── SCORE THRESHOLDS ───────────────────────────────────
  scores: {
    elite: 90,               // urgent Telegram ping
    hot: 75,                 // Telegram ping
    good: 60,                // dashboard only
    watchlist: 45            // saved but no alert
  },

  // ─── FEES ───────────────────────────────────────────────
  fees: {
    ebay: 0.13,              // 13% final value fee
    ebayInsertion: 0.35,     // per listing fee
    depop: 0.10,             // 10%
    vinted: 0.00,            // no seller fee
    paymentProcessing: 0.02  // 2% payment processing
  },

  // ─── POSTAGE ────────────────────────────────────────────
  postage: {
    clothing_small: 3.20,    // Evri small parcel
    clothing_large: 4.50,    // Evri medium parcel
    electronics_small: 4.50,
    electronics_large: 6.50,
    books: 2.80,
    default: 4.50
  },

  // ─── SEARCH KEYWORDS ────────────────────────────────────
  keywords: {
    vinted: [
      'ralph lauren', 'stone island', 'north face',
      'nike air max', 'adidas', 'levi', 'carhartt',
      'cp company', 'moncler', 'canada goose',
      'lacoste', 'burberry', 'hugo boss'
    ],
    ibidder: [
      'electronics', 'camera', 'tools', 'watches',
      'laptop', 'iphone', 'playstation', 'xbox',
      'guitar', 'vintage', 'collectibles', 'jewellery'
    ],
    gumtree: [
      'electronics', 'tools', 'furniture',
      'bikes', 'camera', 'laptop', 'gaming'
    ]
  },

  // ─── HARD REJECT WORDS ──────────────────────────────────
  rejectWords: [
    'spares', 'repair', 'faulty', 'broken', 'damaged',
    'cracked', 'for parts', 'not working', 'untested',
    'water damage', 'spares or repair', 'collection only',
    'no returns', 'sold as seen'
  ],

  // ─── CAPITAL MANAGEMENT ─────────────────────────────────
  maxSingleItemBudget: 150,  // never spend more than this per item
  targetMonthlyProfit: 1000, // goal tracker target

  // ─── HOLD PENALTIES ─────────────────────────────────────
  holdPenalty: {
    under7days: 0,
    under14days: 1.50,
    under30days: 4.00,
    over30days: 9.00
  },

  // ─── SOURCES ────────────────────────────────────────────
  // Add new sources here — nothing else changes
  sources: [
    require('../sources/vinted'),
    require('../sources/ibidder'),
    require('../sources/gumtree')
  ]
};
