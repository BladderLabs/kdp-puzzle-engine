// sources/vinted.js
// Vinted clothing deals via Apify actor

const axios   = require('axios');
const settings = require('../config/settings');

const SOURCE_NAME = 'vinted';
const ACTOR_ID    = 'keboola/vinted-scraper'; // Apify store actor

async function scrape(keywords) {
  const token = process.env.APIFY_TOKEN;

  if (!token || token === 'your_apify_token_here') {
    console.log('[Vinted] No Apify token — using direct API fallback');
    return await scrapeDirectly(keywords);
  }

  try {
    return await scrapeViaApify(keywords, token);
  } catch (err) {
    console.error('[Vinted] Apify failed, using direct fallback:', err.message);
    return await scrapeDirectly(keywords);
  }
}

// ─── VIA APIFY ───────────────────────────────────────────────────────────────
async function scrapeViaApify(keywords, token) {
  const results = [];

  for (const keyword of keywords) {
    try {
      // Start actor run
      const startRes = await axios.post(
        `https://api.apify.com/v2/acts/${ACTOR_ID}/runs`,
        {
          searchText:  keyword,
          maxItems:    30,
          country:     'GB',
          currency:    'GBP',
          sortOrder:   'newest_first'
        },
        {
          headers: { Authorization: `Bearer ${token}` },
          params:  { token }
        }
      );

      const runId = startRes.data?.data?.id;
      if (!runId) continue;

      // Wait for completion
      await waitForRun(runId, token);

      // Get results
      const dataRes = await axios.get(
        `https://api.apify.com/v2/actor-runs/${runId}/dataset/items`,
        { params: { token } }
      );

      const items = dataRes.data || [];

      items.forEach(item => {
        const price = parseFloat(item.price || item.priceNumeric || 0);
        if (!price || price > settings.maxAskingPrice) return;

        results.push(standardise({
          title:     `${item.brand || ''} ${item.title || item.name || ''}`.trim(),
          price,
          photos:    item.photos?.length || item.photoCount || 1,
          desc:      item.description || item.title || '',
          condition: item.status || item.condition || '',
          brand:     item.brand || '',
          url:       item.url || item.itemUrl || ''
        }));
      });

      await sleep(1500);
    } catch (err) {
      console.error(`[Vinted Apify] "${keyword}":`, err.message);
    }
  }

  return results;
}

// ─── DIRECT API FALLBACK ─────────────────────────────────────────────────────
async function scrapeDirectly(keywords) {
  const results = [];

  for (const keyword of keywords) {
    try {
      const res = await axios.get('https://www.vinted.co.uk/api/v2/catalog/items', {
        params: {
          search_text:  keyword,
          per_page:     30,
          order:        'newest_first',
          currency:     'GBP'
        },
        headers: {
          'User-Agent':      'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X)',
          'Accept':          'application/json',
          'Accept-Language': 'en-GB'
        },
        timeout: 10000
      });

      const items = res.data?.items || [];

      items.forEach(item => {
        const price = parseFloat(item.price?.amount || item.price || 0);
        if (!price || price > settings.maxAskingPrice) return;

        results.push(standardise({
          title:     `${item.brand_title || ''} ${item.title || ''}`.trim(),
          price,
          photos:    item.photos?.length || 0,
          desc:      item.title || '',
          condition: item.status || '',
          brand:     item.brand_title || '',
          url:       `https://www.vinted.co.uk/items/${item.id}`
        }));
      });

      await sleep(1500);
    } catch (err) {
      console.error(`[Vinted Direct] "${keyword}":`, err.message);
    }
  }

  return results;
}

// ─── STANDARDISE OUTPUT ──────────────────────────────────────────────────────
function standardise(raw) {
  return {
    source:        SOURCE_NAME,
    title:         raw.title || '',
    askingPrice:   raw.price,
    photoCount:    raw.photos || 0,
    descWordCount: (raw.desc || '').split(' ').filter(Boolean).length,
    daysListed:    0,
    condition:     raw.condition || '',
    category:      'clothing',
    location:      'UK',
    brand:         raw.brand || '',
    url:           raw.url || '',
    foundAt:       new Date().toISOString()
  };
}

// ─── WAIT FOR APIFY RUN ──────────────────────────────────────────────────────
async function waitForRun(runId, token, maxWait = 60000) {
  const start = Date.now();
  while (Date.now() - start < maxWait) {
    await sleep(3000);
    const res = await axios.get(
      `https://api.apify.com/v2/actor-runs/${runId}`,
      { params: { token } }
    );
    const status = res.data?.data?.status;
    if (status === 'SUCCEEDED') return;
    if (status === 'FAILED' || status === 'ABORTED') throw new Error(`Run ${status}`);
  }
  throw new Error('Run timed out');
}

const sleep = ms => new Promise(r => setTimeout(r, ms));

module.exports = { scrape, SOURCE_NAME };
