// sources/ibidder.js
// i-bidder.com auction lots via Apify + fallback

const axios    = require('axios');
const cheerio  = require('cheerio');
const settings = require('../config/settings');

const SOURCE_NAME = 'ibidder';

async function scrape(keywords) {
  const token = process.env.APIFY_TOKEN;

  try {
    if (token && token !== 'your_apify_token_here') {
      return await scrapeViaApify(keywords, token);
    }
  } catch (err) {
    console.error('[i-bidder] Apify failed, using direct:', err.message);
  }

  return await scrapeDirectly(keywords);
}

// ─── VIA APIFY ───────────────────────────────────────────────────────────────
async function scrapeViaApify(keywords, token) {
  const results = [];

  for (const keyword of keywords) {
    try {
      const startRes = await axios.post(
        'https://api.apify.com/v2/acts/apify~web-scraper/runs',
        {
          startUrls: [{
            url: `https://www.i-bidder.com/en-gb/auction-catalogues/search?q=${encodeURIComponent(keyword)}&sortby=enddate_asc`
          }],
          pageFunction: `
            async function pageFunction(context) {
              const { $, request } = context;
              const items = [];
              $('.lot-card, [class*="lot-item"]').each((i, el) => {
                items.push({
                  title:     $(el).find('[class*="title"], h2, h3').first().text().trim(),
                  price:     $(el).find('[class*="price"], [class*="bid"]').first().text().trim(),
                  photos:    $(el).find('img').length,
                  desc:      $(el).find('p, [class*="desc"]').first().text().trim(),
                  endTime:   $(el).find('[class*="time"], [class*="end"]').first().text().trim(),
                  url:       $(el).find('a').first().attr('href') || ''
                });
              });
              return items;
            }
          `,
          maxRequestsPerCrawl: 1
        },
        { params: { token } }
      );

      const runId = startRes.data?.data?.id;
      if (!runId) continue;
      await waitForRun(runId, token);

      const dataRes = await axios.get(
        `https://api.apify.com/v2/actor-runs/${runId}/dataset/items`,
        { params: { token } }
      );

      const items = dataRes.data || [];
      items.flat().forEach(item => {
        const price = parseFloat((item.price || '').replace(/[^0-9.]/g, '')) || 0;
        if (!price || price > settings.maxAskingPrice) return;
        results.push(standardise({ ...item, price, keyword }));
      });

      await sleep(2000);
    } catch (err) {
      console.error(`[i-bidder Apify] "${keyword}":`, err.message);
    }
  }

  return results;
}

// ─── DIRECT SCRAPE FALLBACK ──────────────────────────────────────────────────
async function scrapeDirectly(keywords) {
  const results = [];

  for (const keyword of keywords) {
    try {
      const url = `https://www.i-bidder.com/en-gb/auction-catalogues/search?q=${encodeURIComponent(keyword)}&sortby=enddate_asc`;
      const res = await axios.get(url, {
        headers: {
          'User-Agent':      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120',
          'Accept-Language': 'en-GB,en;q=0.9'
        },
        timeout: 12000
      });

      const $ = cheerio.load(res.data);

      $('[class*="lot"], .lot-card, article').each((i, el) => {
        const title    = $(el).find('[class*="title"], h2, h3').first().text().trim();
        const priceStr = $(el).find('[class*="price"], [class*="bid"]').first().text();
        const price    = parseFloat(priceStr.replace(/[^0-9.]/g, '')) || 0;
        const photos   = $(el).find('img').length;
        const desc     = $(el).find('p').first().text().trim();
        const endTime  = $(el).find('[class*="time"]').first().text().trim();
        const href     = $(el).find('a').first().attr('href') || '';

        if (title && price > 0 && price <= settings.maxAskingPrice) {
          results.push(standardise({
            title, price, photos, desc,
            endTime,
            url: href.startsWith('http') ? href : `https://www.i-bidder.com${href}`,
            keyword
          }));
        }
      });

      await sleep(2000);
    } catch (err) {
      console.error(`[i-bidder Direct] "${keyword}":`, err.message);
    }
  }

  return results;
}

// ─── STANDARDISE ─────────────────────────────────────────────────────────────
function standardise(raw) {
  const endTime   = raw.endTime || '';
  const hoursLeft = parseHoursLeft(endTime);

  return {
    source:        SOURCE_NAME,
    title:         raw.title || '',
    askingPrice:   raw.price,
    photoCount:    raw.photos || 0,
    descWordCount: (raw.desc || '').split(' ').filter(Boolean).length,
    daysListed:    0,
    condition:     '',
    category:      raw.keyword || 'general',
    location:      'UK',
    url:           raw.url || '',
    isAuction:     true,
    endTime:       raw.endTime || '',
    hoursLeft,
    auctionUrgency: hoursLeft < 1    ? 'ENDING_NOW'
      : hoursLeft < 6  ? 'ENDING_SOON'
      : hoursLeft < 24 ? 'TODAY'
      : 'UPCOMING',
    foundAt:       new Date().toISOString()
  };
}

function parseHoursLeft(timeStr) {
  if (!timeStr) return 999;
  const hMatch = timeStr.match(/(\d+)\s*h/i);
  const dMatch = timeStr.match(/(\d+)\s*d/i);
  const mMatch = timeStr.match(/(\d+)\s*m/i);
  const hours  = (dMatch ? parseInt(dMatch[1]) * 24 : 0)
    + (hMatch ? parseInt(hMatch[1]) : 0)
    + (mMatch ? parseInt(mMatch[1]) / 60 : 0);
  return hours || 999;
}

async function waitForRun(runId, token, maxWait = 60000) {
  const start = Date.now();
  while (Date.now() - start < maxWait) {
    await sleep(3000);
    const res    = await axios.get(`https://api.apify.com/v2/actor-runs/${runId}`, { params: { token } });
    const status = res.data?.data?.status;
    if (status === 'SUCCEEDED') return;
    if (status === 'FAILED' || status === 'ABORTED') throw new Error(`Run ${status}`);
  }
  throw new Error('Run timed out');
}

const sleep = ms => new Promise(r => setTimeout(r, ms));

module.exports = { scrape, SOURCE_NAME };
