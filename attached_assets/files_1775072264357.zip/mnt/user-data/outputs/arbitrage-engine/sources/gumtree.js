// sources/gumtree.js
// Gumtree Sheffield + UK listings

const axios    = require('axios');
const cheerio  = require('cheerio');
const settings = require('../config/settings');

const SOURCE_NAME = 'gumtree';

async function scrape(keywords) {
  const results = [];

  for (const keyword of keywords) {
    try {
      // Sheffield first, then UK-wide
      const urls = [
        `https://www.gumtree.com/search?search_category=all&q=${encodeURIComponent(keyword)}&search_location=sheffield&distance=30&sort=date`,
        `https://www.gumtree.com/search?search_category=all&q=${encodeURIComponent(keyword)}&sort=date`
      ];

      for (const url of urls) {
        const res = await axios.get(url, {
          headers: {
            'User-Agent':      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120',
            'Accept':          'text/html,application/xhtml+xml',
            'Accept-Language': 'en-GB,en;q=0.9'
          },
          timeout: 12000
        });

        const $ = cheerio.load(res.data);

        $('article, [data-q="search-result"], .listing-maxi').each((i, el) => {
          const title    = $(el).find('h2, [class*="title"]').first().text().trim();
          const priceStr = $(el).find('[class*="price"]').first().text().trim();
          const price    = parseFloat(priceStr.replace(/[^0-9.]/g, '')) || 0;
          const desc     = $(el).find('[class*="description"], p').first().text().trim();
          const photos   = $(el).find('img').length;
          const dateText = $(el).find('[class*="date"], time').first().text().trim();
          const href     = $(el).find('a').first().attr('href') || '';

          if (title && price > 1 && price <= settings.maxAskingPrice) {
            results.push(standardise({
              title, price, desc, photos,
              dateText,
              url: href.startsWith('http') ? href : `https://www.gumtree.com${href}`,
              keyword
            }));
          }
        });

        await sleep(2000);
      }
    } catch (err) {
      console.error(`[Gumtree] "${keyword}":`, err.message);
    }
  }

  // Deduplicate by URL
  const seen = new Set();
  return results.filter(r => {
    if (seen.has(r.url)) return false;
    seen.add(r.url);
    return true;
  });
}

function standardise(raw) {
  return {
    source:        SOURCE_NAME,
    title:         raw.title || '',
    askingPrice:   raw.price,
    photoCount:    raw.photos || 0,
    descWordCount: (raw.desc || '').split(' ').filter(Boolean).length,
    daysListed:    parseDaysListed(raw.dateText),
    condition:     '',
    category:      raw.keyword || 'general',
    location:      'Sheffield/UK',
    url:           raw.url || '',
    isAuction:     false,
    foundAt:       new Date().toISOString()
  };
}

function parseDaysListed(text) {
  if (!text) return 0;
  if (text.toLowerCase().includes('today'))     return 0;
  if (text.toLowerCase().includes('yesterday')) return 1;
  const m = text.match(/(\d+)\s*(day|week|month)/i);
  if (!m) return 0;
  const n = parseInt(m[1]);
  const u = m[2].toLowerCase();
  if (u === 'week')  return n * 7;
  if (u === 'month') return n * 30;
  return n;
}

const sleep = ms => new Promise(r => setTimeout(r, ms));

module.exports = { scrape, SOURCE_NAME };
