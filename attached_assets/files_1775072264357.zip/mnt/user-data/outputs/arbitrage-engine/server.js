// server.js — Arbitrage Engine
require('dotenv').config();

const express  = require('express');
const cron     = require('node-cron');
const cors     = require('cors');
const path     = require('path');

const pipeline = require('./core/pipeline');
const settings = require('./config/settings');
const dealsDb  = require('./db/deals');
const invDb    = require('./db/inventory');
const learner  = require('./intelligence/learner');
const telegram = require('./alerts/telegram');
const scorer   = require('./intelligence/scorer');
const ebay     = require('./intelligence/ebay');

const app  = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ─── STATE ───────────────────────────────────────────────────────────────────
let isScanning   = false;
let lastScanTime = null;
let scanCount    = 0;

// ─── ROUTES — DEALS ──────────────────────────────────────────────────────────

app.get('/api/deals', (req, res) => {
  const deals = dealsDb.getDeals({
    minScore: req.query.min,
    source:   req.query.source,
    verdict:  req.query.verdict,
    sort:     req.query.sort,
    limit:    parseInt(req.query.limit) || 100
  });
  res.json({ deals, total: deals.length, lastScan: lastScanTime });
});

app.get('/api/deals/stats', (req, res) => {
  res.json({ ...dealsDb.getStats(), isScanning, scanCount });
});

app.delete('/api/deals/:id', (req, res) => {
  dealsDb.removeDeal(req.params.id);
  res.json({ ok: true });
});

app.post('/api/deals/:id/buy', (req, res) => {
  const deal = dealsDb.getDeal(req.params.id);
  if (!deal) return res.status(404).json({ error: 'Deal not found' });

  const item = invDb.addToInventory({
    title:             deal.title,
    buyPrice:          deal.askingPrice,
    source:            deal.source,
    category:          deal.category,
    condition:         deal.condition,
    expectedProfit:    deal.profit?.netProfit,
    expectedSellPrice: deal.profit?.sellPrice,
    dealId:            deal.id
  });

  res.json({ ok: true, inventoryItem: item });
});

// ─── ROUTES — MANUAL SCORER ───────────────────────────────────────────────────

app.post('/api/score', async (req, res) => {
  const { title, price, category } = req.body;
  if (!title || !price) return res.status(400).json({ error: 'title and price required' });

  try {
    const clean  = pipeline.cleanTitle(title);
    const market = await ebay.getSoldData(clean);

    if (!market) {
      return res.json({
        verdict:  'NO_DATA',
        message:  'No eBay sold data found for this item. Try different keywords.',
        market:   null,
        scoring:  null
      });
    }

    const fakeItem = {
      title, askingPrice: parseFloat(price),
      photoCount: 5, descWordCount: 30,
      daysListed: 0, category: category || 'general',
      source: 'manual'
    };

    const scoring = scorer.score(fakeItem, market, learner.getMultipliers());

    // Calculate max bid if auction
    const maxBid = scorer.calculateMaxBid(market.medianSoldPrice, category || 'general');

    res.json({ verdict: scoring?.verdict || 'SKIP', market, scoring, maxBid, cleanedTitle: clean });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── ROUTES — INVENTORY ──────────────────────────────────────────────────────

app.get('/api/inventory', (req, res) => {
  const inventory = invDb.getInventory();
  const status    = req.query.status;
  const filtered  = status ? inventory.filter(i => i.status === status) : inventory;
  res.json({ inventory: filtered, total: filtered.length });
});

app.post('/api/inventory', (req, res) => {
  const item = invDb.addToInventory(req.body);
  res.json({ ok: true, item });
});

app.patch('/api/inventory/:id/listed', (req, res) => {
  const { listingPrice, channel } = req.body;
  const item = invDb.markAsListed(req.params.id, listingPrice, channel);
  res.json({ ok: true, item });
});

app.patch('/api/inventory/:id/sold', (req, res) => {
  const { soldPrice, fees, postage } = req.body;
  const item = invDb.markAsSold(req.params.id, soldPrice, fees, postage);

  // Log outcome to learning engine
  if (item) {
    learner.logOutcome(
      item.dealId,
      item.realProfit,
      item.daysHeld,
      item.category,
      item.source
    );
  }
  res.json({ ok: true, item });
});

// ─── ROUTES — P&L ────────────────────────────────────────────────────────────

app.get('/api/pnl', (req, res) => {
  const period = req.query.period || 'month';
  res.json(invDb.getPnL(period));
});

app.get('/api/transactions', (req, res) => {
  res.json({ transactions: invDb.getTransactions() });
});

// ─── ROUTES — LEARNING ───────────────────────────────────────────────────────

app.get('/api/learning', (req, res) => {
  res.json(learner.getLearningReport());
});

// ─── ROUTES — SCAN CONTROL ───────────────────────────────────────────────────

app.post('/api/scan', (req, res) => {
  if (isScanning) return res.json({ ok: false, message: 'Scan already running' });
  res.json({ ok: true, message: 'Scan started' });
  runScan();
});

app.get('/api/status', (req, res) => {
  res.json({
    status:      'running',
    isScanning,
    lastScan:    lastScanTime,
    scanCount,
    uptime:      process.uptime(),
    sources:     settings.sources.map(s => s.SOURCE_NAME),
    nextScan:    `Every ${settings.scanInterval} minutes`
  });
});

// ─── CORE SCAN ───────────────────────────────────────────────────────────────

async function runScan() {
  if (isScanning) return;
  isScanning = true;
  scanCount++;

  console.log(`\n[${new Date().toLocaleTimeString()}] Scan #${scanCount} starting...`);

  try {
    const allRawItems = [];

    // Collect from all sources in parallel
    const sourceResults = await Promise.allSettled(
      settings.sources.map(source =>
        source.scrape(settings.keywords[source.SOURCE_NAME] || settings.keywords.gumtree)
      )
    );

    sourceResults.forEach((result, i) => {
      if (result.status === 'fulfilled') {
        allRawItems.push(...result.value);
        console.log(`[${settings.sources[i].SOURCE_NAME}] ${result.value.length} raw items`);
      } else {
        console.error(`[Source ${i}] Failed:`, result.reason?.message);
      }
    });

    console.log(`Total raw: ${allRawItems.length} items`);

    // Process through pipeline
    const deals = await pipeline.processBatch(allRawItems);

    console.log(`Scored: ${deals.length} deals passed filters`);

    // Save to DB
    const newCount = dealsDb.addDeals(deals);
    console.log(`New deals: ${newCount}`);

    // Send alerts
    const hotDeals   = deals.filter(d => d.verdict === 'HOT' || d.verdict === 'ELITE');
    const auctionEnd = deals.filter(d => d.isAuction && d.hoursLeft < 6);

    for (const deal of hotDeals.slice(0, 5)) {  // max 5 alerts per scan
      await telegram.sendDealAlert(deal);
    }

    for (const deal of auctionEnd) {
      await telegram.sendAuctionAlert(deal);
    }

    if (newCount > 0) {
      const stats = dealsDb.getStats();
      await telegram.sendScanSummary({
        newDeals: newCount,
        elite:    deals.filter(d => d.verdict === 'ELITE').length,
        hot:      deals.filter(d => d.verdict === 'HOT').length,
        good:     deals.filter(d => d.verdict === 'GOOD').length,
        sources:  [...new Set(deals.map(d => d.source))]
      });
    }

    lastScanTime = new Date().toISOString();
  } catch (err) {
    console.error('[Scan] Error:', err.message);
  } finally {
    isScanning = false;
  }
}

// ─── SCHEDULER ───────────────────────────────────────────────────────────────

cron.schedule(`*/${settings.scanInterval} * * * *`, () => {
  console.log('[Scheduler] Triggered');
  runScan();
});

// ─── START ───────────────────────────────────────────────────────────────────

app.listen(PORT, () => {
  console.log(`\n🚀 Arbitrage Engine running on port ${PORT}`);
  console.log(`📊 Dashboard: http://localhost:${PORT}`);
  console.log(`⏱  Scanning every ${settings.scanInterval} minutes\n`);

  // First scan on startup
  setTimeout(runScan, 3000);
});
