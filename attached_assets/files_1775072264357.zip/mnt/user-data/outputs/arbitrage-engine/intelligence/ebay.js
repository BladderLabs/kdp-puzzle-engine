// intelligence/ebay.js
// Market intelligence layer — real sold price data
// Works WITHOUT official API approval using fallback scraper

const axios = require('axios');
const settings = require('../config/settings');

const EBAY_APP_ID = process.env.EBAY_APP_ID;

// ─── MAIN FUNCTION ───────────────────────────────────────────────────────────
async function getSoldData(keywords) {
  // Try official API first if key exists
  if (EBAY_APP_ID && EBAY_APP_ID !== 'your_ebay_app_id_here') {
    const official = await getViaOfficialAPI(keywords);
    if (official) return official;
  }

  // Fallback — scrape eBay sold listings directly
  return await getViaFallback(keywords);
}

// ─── OFFICIAL API PATH ───────────────────────────────────────────────────────
async function getViaOfficialAPI(keywords) {
  try {
    const params = {
      'OPERATION-NAME': 'findCompletedItems',
      'SERVICE-VERSION': '1.0.0',
      'SECURITY-APPNAME': EBAY_APP_ID,
      'RESPONSE-DATA-FORMAT': 'JSON',
      'keywords': keywords,
      'itemFilter(0).name': 'SoldItemsOnly',
      'itemFilter(0).value': 'true',
      'itemFilter(1).name': 'LocatedIn',
      'itemFilter(1).value': 'GB',
      'paginationInput.entriesPerPage': '50',
      'sortOrder': 'EndTimeSoonest'
    };

    const res = await axios.get(
      'https://svcs.ebay.com/services/search/FindingService/v1',
      { params, timeout: 8000 }
    );

    const items = res.data
      ?.findCompletedItemsResponse?.[0]
      ?.searchResult?.[0]?.item || [];

    if (items.length < 3) return null;

    return processItems(items, 'api');
  } catch (err) {
    console.log('Official API failed, using fallback:', err.message);
    return null;
  }
}

// ─── FALLBACK SCRAPER ────────────────────────────────────────────────────────
async function getViaFallback(keywords) {
  try {
    const cheerio = require('cheerio');
    const encoded = encodeURIComponent(keywords);
    const url = `https://www.ebay.co.uk/sch/i.html?_nkw=${encoded}&LH_Complete=1&LH_Sold=1&LH_ItemCondition=3&_sacat=0&_from=R40&rt=nc`;

    const res = await axios.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36',
        'Accept-Language': 'en-GB,en;q=0.9',
        'Accept': 'text/html,application/xhtml+xml'
      },
      timeout: 10000
    });

    const $ = cheerio.load(res.data);
    const prices = [];
    const dates = [];

    $('.s-item').each((i, el) => {
      const priceText = $(el).find('.s-item__price').first().text();
      const price = parseFloat(priceText.replace(/[^0-9.]/g, ''));
      const dateText = $(el).find('.s-item__ended-date, .s-item__listingDate').text();

      if (price > 0 && price < 2000) {
        prices.push(price);
        if (dateText) dates.push(dateText);
      }
    });

    if (prices.length < 3) return null;

    // Get live competitor count
    const competitorCount = await getLiveCount(keywords);

    return buildIntelligence(prices, competitorCount);
  } catch (err) {
    console.error('eBay fallback error:', err.message);
    return null;
  }
}

// ─── PROCESS API ITEMS ───────────────────────────────────────────────────────
function processItems(items, source) {
  const prices = items.map(i =>
    parseFloat(i.sellingStatus?.[0]?.currentPrice?.[0]?.__value__ || 0)
  ).filter(p => p > 0);

  const daysList = items.map(i => {
    const end   = new Date(i.listingInfo?.[0]?.endTime?.[0]).getTime();
    const start = new Date(i.listingInfo?.[0]?.startTime?.[0]).getTime();
    return (end - start) / (1000 * 60 * 60 * 24);
  }).filter(d => d > 0 && d < 90);

  const competitorCount = 0; // will be fetched separately if needed

  return buildIntelligence(prices, competitorCount, daysList);
}

// ─── BUILD INTELLIGENCE PROFILE ─────────────────────────────────────────────
function buildIntelligence(prices, competitorCount, daysList = []) {
  const sorted = [...prices].sort((a, b) => a - b);
  const avg    = prices.reduce((s, p) => s + p, 0) / prices.length;
  const median = sorted[Math.floor(sorted.length / 2)];
  const lowest = sorted[0];
  const highest = sorted[sorted.length - 1];

  const avgDays = daysList.length
    ? daysList.reduce((s, d) => s + d, 0) / daysList.length
    : 10;

  // Price direction — compare first half vs second half of results
  const mid = Math.floor(prices.length / 2);
  const recentAvg = prices.slice(0, mid).reduce((s, p) => s + p, 0) / mid || avg;
  const olderAvg  = prices.slice(mid).reduce((s, p) => s + p, 0) / (prices.length - mid) || avg;
  const direction = recentAvg > olderAvg * 1.10 ? 'RISING'
    : recentAvg < olderAvg * 0.90 ? 'FALLING'
    : 'STABLE';

  const demandScore = prices.length / (competitorCount + 1);

  return {
    avgSoldPrice:      Math.round(avg * 100) / 100,
    medianSoldPrice:   Math.round(median * 100) / 100,
    lowestSold:        Math.round(lowest * 100) / 100,
    highestSold:       Math.round(highest * 100) / 100,
    soldCount:         prices.length,
    daysToSell:        Math.round(avgDays),
    competitorCount,
    priceDirection:    direction,
    demandScore:       Math.round(demandScore * 100) / 100
  };
}

// ─── LIVE COMPETITOR COUNT ───────────────────────────────────────────────────
async function getLiveCount(keywords) {
  try {
    if (!EBAY_APP_ID || EBAY_APP_ID === 'your_ebay_app_id_here') return 5;

    const res = await axios.get(
      'https://svcs.ebay.com/services/search/FindingService/v1',
      {
        params: {
          'OPERATION-NAME': 'findItemsByKeywords',
          'SERVICE-VERSION': '1.0.0',
          'SECURITY-APPNAME': EBAY_APP_ID,
          'RESPONSE-DATA-FORMAT': 'JSON',
          'keywords': keywords,
          'paginationInput.entriesPerPage': '1'
        },
        timeout: 5000
      }
    );

    return parseInt(
      res.data?.findItemsByKeywordsResponse?.[0]
        ?.paginationOutput?.[0]?.totalEntries?.[0] || 5
    );
  } catch {
    return 5;
  }
}

module.exports = { getSoldData };
