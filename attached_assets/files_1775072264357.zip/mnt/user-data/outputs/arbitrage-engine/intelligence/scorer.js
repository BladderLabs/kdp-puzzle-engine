// intelligence/scorer.js
// Core scoring algorithm — every deal scored 0-100+

const settings = require('../config/settings');

// ─── MAIN SCORE FUNCTION ─────────────────────────────────────────────────────
function score(item, market, multipliers = {}) {

  const {
    askingPrice,
    photoCount    = 0,
    descWordCount = 0,
    daysListed    = 0,
    category      = 'default',
    source        = 'unknown'
  } = item;

  const {
    medianSoldPrice,
    soldCount,
    daysToSell,
    competitorCount,
    priceDirection,
    demandScore
  } = market;

  // ─── HARD BLOCKERS ─────────────────────────────────────
  if (medianSoldPrice <= 0)                  return null;
  if (soldCount < settings.minSoldCount)     return null;
  if (askingPrice > settings.maxSingleItemBudget) return null;

  // ─── PROFIT CALCULATION ────────────────────────────────
  const profit = calculateProfit(askingPrice, medianSoldPrice, category, daysToSell);

  if (profit.netProfit < settings.minNetProfit) return null;
  if (profit.roi < settings.minROI)             return null;

  // ─── APPLY LEARNED MULTIPLIERS ─────────────────────────
  const categoryKey = `${category}_${source}`.toLowerCase().replace(/\s/g, '_');
  const profitMultiplier = multipliers[categoryKey] || 1.0;
  const adjustedProfit   = profit.netProfit * profitMultiplier;

  // ─── SCORE DIMENSIONS ──────────────────────────────────

  // Dimension 1: Net Profit (35 pts)
  const profitScore = adjustedProfit >= 40 ? 35
    : adjustedProfit >= 25 ? 30
    : adjustedProfit >= 15 ? 20
    : adjustedProfit >= 8  ? 10
    : 0;

  // Dimension 2: Market Position (25 pts)
  const belowPct        = (medianSoldPrice - askingPrice) / medianSoldPrice * 100;
  const belowMarketScore = belowPct >= 40 ? 25
    : belowPct >= 30 ? 21
    : belowPct >= 20 ? 15
    : belowPct >= 10 ? 8
    : 0;

  // Dimension 3: Liquidity (20 pts)
  const liquidityScore = daysToSell < 4  ? 20
    : daysToSell < 7  ? 17
    : daysToSell < 14 ? 12
    : daysToSell < 21 ? 6
    : daysToSell < 30 ? 2
    : 0;

  // Dimension 4: Risk (20 pts, deductions from 20)
  let riskScore = 20;
  if (photoCount < 3)          riskScore -= 8;
  if (descWordCount < 20)      riskScore -= 5;
  if (competitorCount > 15)    riskScore -= 4;
  if (daysListed > 14)         riskScore -= 3;
  if (priceDirection === 'FALLING') riskScore -= 5;
  if (demandScore < 0.5)       riskScore -= 5;
  riskScore = Math.max(riskScore, 0);

  // ─── BONUSES ───────────────────────────────────────────
  let bonus = 0;
  if (demandScore > 3.0)       bonus += 5;
  if (priceDirection === 'RISING') bonus += 5;
  if (soldCount > 50)          bonus += 3;
  if (photoCount > 8)          bonus += 2;

  // ─── FINAL SCORE ───────────────────────────────────────
  const total = Math.round(
    profitScore + belowMarketScore + liquidityScore + riskScore + bonus
  );

  // ─── VERDICT ───────────────────────────────────────────
  const verdict = total >= settings.scores.elite ? 'ELITE'
    : total >= settings.scores.hot   ? 'HOT'
    : total >= settings.scores.good  ? 'GOOD'
    : total >= settings.scores.watchlist ? 'WATCHLIST'
    : 'SKIP';

  return {
    total,
    verdict,
    breakdown: {
      profitScore,
      belowMarketScore,
      liquidityScore,
      riskScore,
      bonus
    },
    profit: {
      ...profit,
      adjusted: Math.round(adjustedProfit * 100) / 100
    },
    belowMarketPct:    Math.round(belowPct),
    multiplierApplied: profitMultiplier
  };
}

// ─── PROFIT CALCULATOR ───────────────────────────────────────────────────────
function calculateProfit(buyPrice, sellPrice, category, daysToSell) {
  const cat        = (category || '').toLowerCase();
  const postage    = getPostage(cat);
  const feeRate    = settings.fees.ebay + settings.fees.paymentProcessing;
  const insertion  = settings.fees.ebayInsertion;
  const totalFees  = (sellPrice * feeRate) + insertion + postage;
  const netProfit  = sellPrice - buyPrice - totalFees;
  const roi        = (netProfit / buyPrice) * 100;

  // Hold penalty
  const holdPenalty = daysToSell < 7  ? settings.holdPenalty.under7days
    : daysToSell < 14 ? settings.holdPenalty.under14days
    : daysToSell < 30 ? settings.holdPenalty.under30days
    : settings.holdPenalty.over30days;

  const realNetProfit = netProfit - holdPenalty;

  return {
    buyPrice:       Math.round(buyPrice * 100) / 100,
    sellPrice:      Math.round(sellPrice * 100) / 100,
    totalFees:      Math.round(totalFees * 100) / 100,
    postage:        Math.round(postage * 100) / 100,
    netProfit:      Math.round(netProfit * 100) / 100,
    realNetProfit:  Math.round(realNetProfit * 100) / 100,
    roi:            Math.round(roi),
    holdPenalty
  };
}

// ─── POSTAGE ESTIMATOR ───────────────────────────────────────────────────────
function getPostage(category) {
  if (category.includes('cloth') || category.includes('fashion')
    || category.includes('jacket') || category.includes('shirt'))
    return settings.postage.clothing_small;
  if (category.includes('electronic') || category.includes('laptop')
    || category.includes('camera'))
    return settings.postage.electronics_large;
  if (category.includes('book'))
    return settings.postage.books;
  return settings.postage.default;
}

// ─── AUCTION MAX BID CALCULATOR ──────────────────────────────────────────────
function calculateMaxBid(medianSoldPrice, category, targetProfit = 25) {
  const postage   = getPostage(category);
  const feeRate   = settings.fees.ebay + settings.fees.paymentProcessing;
  const fees      = (medianSoldPrice * feeRate) + settings.fees.ebayInsertion + postage;
  const maxBid    = medianSoldPrice - fees - targetProfit;
  return Math.max(Math.round(maxBid * 100) / 100, 0);
}

module.exports = { score, calculateProfit, calculateMaxBid, getPostage };
