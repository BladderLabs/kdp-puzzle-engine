# ARBITRAGE ENGINE

Automated item flipping intelligence. Scans Vinted, i-bidder, Gumtree every 20 minutes.
Scores every deal against eBay sold data. Alerts you only when it's worth acting.

---

## SETUP ON REPLIT (10 minutes)

### Step 1 — Upload to GitHub
1. Create a GitHub account at github.com
2. Create a new PRIVATE repository called `arbitrage-engine`
3. Upload ALL these files maintaining the folder structure

### Step 2 — Connect GitHub to Replit
1. Go to replit.com → Create Repl → Node.js
2. In the left sidebar click the Git icon
3. Click "Import from GitHub"
4. Select your `arbitrage-engine` repo
5. Click Import

### Step 3 — Add Your Secrets
In Replit, click the PADLOCK icon in the left sidebar (Secrets tab).
Add these one by one:

| Key | Value |
|-----|-------|
| APIFY_TOKEN | Your Apify API token |
| TELEGRAM_BOT_TOKEN | Your Telegram bot token from @BotFather |
| TELEGRAM_CHAT_ID | Your chat ID from @userinfobot |
| EBAY_APP_ID | Your eBay App ID (add when approved) |

### Step 4 — Run It
Click the green RUN button.
It will install packages automatically and start the server.
Open the dashboard URL Replit gives you.

### Step 5 — Enable Always On
In Replit sidebar → your Repl settings → toggle Always On.
This keeps the engine running 24/7.
Cost: $7/month. Without this it sleeps after inactivity.

---

## FOLDER STRUCTURE

```
arbitrage-engine/
├── server.js              Main server
├── package.json           Dependencies
├── .env.example           Environment template
├── .replit                Replit config
├── config/
│   └── settings.js        ALL settings — change anything here
├── core/
│   └── pipeline.js        Item processing — never changes
├── sources/
│   ├── vinted.js          Vinted scraper
│   ├── ibidder.js         i-bidder auction scraper
│   ├── gumtree.js         Gumtree scraper
│   └── _template.js       Copy this to add new sources
├── intelligence/
│   ├── ebay.js            eBay market data
│   ├── scorer.js          Scoring algorithm
│   └── learner.js         Self-learning layer
├── db/
│   ├── deals.js           Deal storage
│   └── inventory.js       Your stock + P&L
├── alerts/
│   └── telegram.js        Telegram notifications
└── public/
    └── index.html         Dashboard
```

---

## ADDING A NEW SOURCE

1. Copy `sources/_template.js` → rename it e.g. `sources/depop.js`
2. Fill in your scraping logic
3. Add one line to `config/settings.js`:
   ```
   sources: [
     require('../sources/vinted'),
     require('../sources/ibidder'),
     require('../sources/gumtree'),
     require('../sources/depop'),  // ← just add this
   ]
   ```
4. Add keywords: `keywords: { depop: ['ralph lauren', ...] }`
5. Nothing else changes anywhere.

---

## CHANGING SETTINGS

Everything is in `config/settings.js`:
- `scanInterval` — how often to scan (minutes)
- `maxAskingPrice` — max item price to consider
- `minNetProfit` — minimum profit floor (£)
- `scores.hot` — threshold for Telegram alerts
- `keywords` — what to search on each platform

---

## USING THE MANUAL SCORER

Open dashboard → tap SCORER tab.
Type any item name and asking price.
Get a verdict in seconds based on real eBay sold data.
Use this at charity shops, car boots, auctions — anywhere.

---

## TELEGRAM SETUP

1. Open Telegram → search @BotFather
2. Type /newbot → follow steps → copy the token
3. Search @userinfobot → message it → copy your Chat ID
4. Add both to Replit Secrets

You'll receive alerts like:
```
🔥 HOT DEAL [84/100]
📦 North Face Jacket Men L
💰 Buy: £18 → Sell: £62
📈 Profit: £34 | ROI: 189%
⚡ Avg sell: 6 days
🏪 Source: vinted
🔗 https://vinted.co.uk/...
```

---

## THE SELF-LEARNING SYSTEM

Every deal you buy and sell gets logged.
Every 10 completed transactions the engine recalibrates:
- Which categories it's been overestimating profit on
- Which sources have faster/slower sell times than eBay average
- Adjusts scoring weights automatically

By month 3 the engine is calibrated to YOUR market specifically.

---

## GITHUB — SAVING UPDATES

Every time you change something:
1. In Replit → Git icon in sidebar
2. See changed files listed
3. Write a commit message e.g. "added Depop scraper"
4. Click Commit & Push

To undo a broken update:
1. Go to github.com → your repo → Commits
2. Find last working version
3. Click ... → Revert
