// scrapers/gumtree.js — Gumtree private seller scraper
const axios = require('axios');
const cheerio = require('cheerio');

const KEYWORDS = process.env.SEARCH_KEYWORDS
  ? process.env.SEARCH_KEYWORDS.split(',')
  : ['electronics', 'tools', 'camera', 'laptop', 'watches'];

async function scrapeGumtree() {
  const results = [];

  for (const keyword of KEYWORDS) {
    try {
      const url = `https://www.gumtree.com/search?search_category=all&q=${encodeURIComponent(keyword)}&search_location=sheffield&distance=30&sort=date`;
      const res = await axios.get(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml',
          'Accept-Language': 'en-GB,en;q=0.9'
        },
        timeout: 10000
      });

      const $ = cheerio.load(res.data);

      $('article.listing-maxi, li.listing-maxi, [data-q="search-result"]').each((i, el) => {
        const title = $(el).find('h2, [class*="title"]').first().text().trim();
        const priceText = $(el).find('[class*="price"]').first().text().trim();
        const price = parseFloat(priceText.replace(/[^0-9.]/g, '')) || 0;
        const desc = $(el).find('[class*="description"], p').first().text().trim();
        const photos = $(el).find('img').length;
        const dateText = $(el).find('[class*="date"], time').first().text().trim();
        const link = $(el).find('a').first().attr('href');

        const daysListed = parseDaysListed(dateText);

        if (title && price > 1 && price < 400) {
          results.push({
            source: 'gumtree',
            title,
            askingPrice: price,
            photoCount: photos,
            descWordCount: desc.split(' ').filter(Boolean).length,
            daysListed,
            category: keyword,
            url: link ? `https://www.gumtree.com${link}` : url,
            foundAt: new Date().toISOString()
          });
        }
      });
    } catch (err) {
      console.error(`Gumtree scrape error for "${keyword}":`, err.message);
    }

    await sleep(2000);
  }

  return results;
}

function parseDaysListed(dateText) {
  if (!dateText) return 0;
  if (dateText.toLowerCase().includes('today')) return 0;
  if (dateText.toLowerCase().includes('yesterday')) return 1;
  const match = dateText.match(/(\d+)\s*(day|week|month)/i);
  if (!match) return 0;
  const num = parseInt(match[1]);
  const unit = match[2].toLowerCase();
  if (unit === 'week')  return num * 7;
  if (unit === 'month') return num * 30;
  return num;
}

const sleep = ms => new Promise(r => setTimeout(r, ms));

module.exports = { scrapeGumtree };
