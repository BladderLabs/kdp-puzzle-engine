// scrapers/ebay.js — eBay sold price intelligence via Finding API
const axios = require('axios');

const EBAY_APP_ID = process.env.EBAY_APP_ID;

async function getEbaySoldData(keywords) {
  try {
    const url = `https://svcs.ebay.com/services/search/FindingService/v1`;
    const params = {
      'OPERATION-NAME': 'findCompletedItems',
      'SERVICE-VERSION': '1.0.0',
      'SECURITY-APPNAME': EBAY_APP_ID,
      'RESPONSE-DATA-FORMAT': 'JSON',
      'keywords': keywords,
      'itemFilter(0).name': 'SoldItemsOnly',
      'itemFilter(0).value': 'true',
      'paginationInput.entriesPerPage': '50',
      'sortOrder': 'EndTimeSoonest'
    };

    const res = await axios.get(url, { params, timeout: 8000 });
    const items = res.data?.findCompletedItemsResponse?.[0]
      ?.searchResult?.[0]?.item || [];

    if (items.length === 0) return null;

    const prices = items.map(i =>
      parseFloat(i.sellingStatus?.[0]?.currentPrice?.[0]?.__value__ || 0)
    ).filter(p => p > 0);

    const avgSoldPrice = prices.reduce((a, b) => a + b, 0) / prices.length;
    const sortedPrices = [...prices].sort((a, b) => a - b);
    const medianSoldPrice = sortedPrices[Math.floor(sortedPrices.length / 2)];

    // Estimate days to sell from listing dates
    const now = Date.now();
    const daysList = items.map(i => {
      const end = new Date(i.listingInfo?.[0]?.endTime?.[0]).getTime();
      const start = new Date(i.listingInfo?.[0]?.startTime?.[0]).getTime();
      return (end - start) / (1000 * 60 * 60 * 24);
    }).filter(d => d > 0 && d < 90);
    const daysToSell = daysList.length
      ? daysList.reduce((a, b) => a + b, 0) / daysList.length
      : 14;

    // Count live competitors
    const competitorCount = await getLiveCompetitorCount(keywords);

    return {
      avgSoldPrice: Math.round(avgSoldPrice * 100) / 100,
      medianSoldPrice: Math.round(medianSoldPrice * 100) / 100,
      soldCount: prices.length,
      daysToSell: Math.round(daysToSell),
      competitorCount
    };
  } catch (err) {
    console.error(`eBay API error for "${keywords}":`, err.message);
    return null;
  }
}

async function getLiveCompetitorCount(keywords) {
  try {
    const url = `https://svcs.ebay.com/services/search/FindingService/v1`;
    const params = {
      'OPERATION-NAME': 'findItemsByKeywords',
      'SERVICE-VERSION': '1.0.0',
      'SECURITY-APPNAME': EBAY_APP_ID,
      'RESPONSE-DATA-FORMAT': 'JSON',
      'keywords': keywords,
      'paginationInput.entriesPerPage': '1'
    };
    const res = await axios.get(url, { params, timeout: 5000 });
    return parseInt(
      res.data?.findItemsByKeywordsResponse?.[0]
        ?.paginationOutput?.[0]?.totalEntries?.[0] || 0
    );
  } catch {
    return 0;
  }
}

module.exports = { getEbaySoldData };
