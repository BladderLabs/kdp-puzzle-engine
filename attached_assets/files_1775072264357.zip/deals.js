// db/deals.js
// All deal read/write operations — isolated data layer

const fs   = require('fs');
const path = require('path');

const DEALS_PATH = path.join(__dirname, 'deals.json');
const MAX_DEALS  = 1000;

function ensureFile() {
  if (!fs.existsSync(DEALS_PATH)) {
    fs.writeFileSync(DEALS_PATH, JSON.stringify([]));
  }
}

function load() {
  ensureFile();
  try { return JSON.parse(fs.readFileSync(DEALS_PATH, 'utf8')); }
  catch { return []; }
}

function save(deals) {
  fs.writeFileSync(DEALS_PATH, JSON.stringify(deals, null, 2));
}

function addDeals(newDeals) {
  const existing    = load();
  const existingUrls = new Set(existing.map(d => d.url));

  // Filter out duplicates
  const unique = newDeals.filter(d => d.url && !existingUrls.has(d.url));

  // Merge, sort by score, cap at MAX_DEALS
  const merged = [...unique, ...existing]
    .sort((a, b) => b.total - a.total)
    .slice(0, MAX_DEALS);

  save(merged);
  return unique.length;
}

function getDeals({ minScore, source, verdict, sort, limit = 100 } = {}) {
  let deals = load();

  if (minScore)  deals = deals.filter(d => d.total >= parseInt(minScore));
  if (source)    deals = deals.filter(d => d.source === source);
  if (verdict)   deals = deals.filter(d => d.verdict === verdict);

  if (sort === 'profit') deals.sort((a, b) => (b.profit?.netProfit || 0) - (a.profit?.netProfit || 0));
  else if (sort === 'price') deals.sort((a, b) => a.askingPrice - b.askingPrice);
  else deals.sort((a, b) => b.total - a.total);

  return deals.slice(0, limit);
}

function getDeal(id) {
  return load().find(d => d.id === id);
}

function removeDeal(id) {
  const deals = load().filter(d => d.id !== id);
  save(deals);
}

function getStats() {
  const deals = load();
  return {
    total:      deals.length,
    elite:      deals.filter(d => d.verdict === 'ELITE').length,
    hot:        deals.filter(d => d.verdict === 'HOT').length,
    good:       deals.filter(d => d.verdict === 'GOOD').length,
    sources:    [...new Set(deals.map(d => d.source))],
    avgScore:   deals.length ? Math.round(deals.reduce((s, d) => s + d.total, 0) / deals.length) : 0,
    avgProfit:  deals.length ? Math.round(deals.reduce((s, d) => s + (d.profit?.netProfit || 0), 0) / deals.length * 100) / 100 : 0
  };
}

module.exports = { load, save, addDeals, getDeals, getDeal, removeDeal, getStats };
