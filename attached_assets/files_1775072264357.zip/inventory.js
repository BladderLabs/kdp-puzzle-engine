// db/inventory.js
// Track everything you own and have sold

const fs   = require('fs');
const path = require('path');

const INVENTORY_PATH    = path.join(__dirname, 'inventory.json');
const TRANSACTIONS_PATH = path.join(__dirname, 'transactions.json');

function ensureFiles() {
  if (!fs.existsSync(INVENTORY_PATH))    fs.writeFileSync(INVENTORY_PATH, JSON.stringify([]));
  if (!fs.existsSync(TRANSACTIONS_PATH)) fs.writeFileSync(TRANSACTIONS_PATH, JSON.stringify([]));
}

// ─── INVENTORY ───────────────────────────────────────────────────────────────

function getInventory() {
  ensureFiles();
  try { return JSON.parse(fs.readFileSync(INVENTORY_PATH, 'utf8')); }
  catch { return []; }
}

function addToInventory(item) {
  const inventory = getInventory();
  const entry = {
    id:              `inv_${Date.now()}`,
    title:           item.title,
    buyPrice:        item.buyPrice,
    source:          item.source,
    category:        item.category || 'general',
    condition:       item.condition || '',
    expectedProfit:  item.expectedProfit || 0,
    expectedSellPrice: item.expectedSellPrice || 0,
    status:          'BOUGHT',       // BOUGHT → LISTED → SOLD → WRITTEN_OFF
    boughtAt:        new Date().toISOString(),
    listedAt:        null,
    soldAt:          null,
    listingPrice:    null,
    soldPrice:       null,
    channel:         null,
    realProfit:      null,
    daysHeld:        0,
    dealId:          item.dealId || null,
    notes:           item.notes || ''
  };
  inventory.push(entry);
  fs.writeFileSync(INVENTORY_PATH, JSON.stringify(inventory, null, 2));
  return entry;
}

function updateInventoryItem(id, updates) {
  const inventory = getInventory();
  const idx       = inventory.findIndex(i => i.id === id);
  if (idx === -1) return null;

  inventory[idx] = { ...inventory[idx], ...updates };

  // Auto-calculate days held
  const bought = new Date(inventory[idx].boughtAt);
  inventory[idx].daysHeld = Math.floor((Date.now() - bought) / (1000 * 60 * 60 * 24));

  // Auto-calculate real profit on sale
  if (updates.soldPrice && updates.status === 'SOLD') {
    inventory[idx].realProfit = updates.soldPrice - inventory[idx].buyPrice
      - (updates.fees || 0) - (updates.postage || 0);
    inventory[idx].soldAt = new Date().toISOString();

    // Log transaction
    logTransaction(inventory[idx]);
  }

  fs.writeFileSync(INVENTORY_PATH, JSON.stringify(inventory, null, 2));
  return inventory[idx];
}

function markAsListed(id, listingPrice, channel) {
  return updateInventoryItem(id, {
    status: 'LISTED',
    listingPrice,
    channel,
    listedAt: new Date().toISOString()
  });
}

function markAsSold(id, soldPrice, fees = 0, postage = 0) {
  return updateInventoryItem(id, {
    status: 'SOLD',
    soldPrice,
    fees,
    postage
  });
}

// ─── TRANSACTIONS ─────────────────────────────────────────────────────────────

function logTransaction(item) {
  const transactions = getTransactions();
  transactions.push({
    id:          `tx_${Date.now()}`,
    inventoryId: item.id,
    title:       item.title,
    buyPrice:    item.buyPrice,
    soldPrice:   item.soldPrice,
    realProfit:  item.realProfit,
    daysHeld:    item.daysHeld,
    source:      item.source,
    channel:     item.channel,
    category:    item.category,
    boughtAt:    item.boughtAt,
    soldAt:      item.soldAt,
    loggedAt:    new Date().toISOString()
  });
  fs.writeFileSync(TRANSACTIONS_PATH, JSON.stringify(transactions, null, 2));
}

function getTransactions() {
  ensureFiles();
  try { return JSON.parse(fs.readFileSync(TRANSACTIONS_PATH, 'utf8')); }
  catch { return []; }
}

// ─── P&L SUMMARY ─────────────────────────────────────────────────────────────

function getPnL(period = 'month') {
  const transactions = getTransactions();
  const now          = new Date();

  const filtered = transactions.filter(tx => {
    const sold = new Date(tx.soldAt || tx.loggedAt);
    if (period === 'month') {
      return sold.getMonth() === now.getMonth()
        && sold.getFullYear() === now.getFullYear();
    }
    if (period === 'week') {
      const weekAgo = new Date(now - 7 * 24 * 60 * 60 * 1000);
      return sold >= weekAgo;
    }
    return true; // 'all'
  });

  const totalSpent    = filtered.reduce((s, t) => s + (t.buyPrice || 0), 0);
  const totalRevenue  = filtered.reduce((s, t) => s + (t.soldPrice || 0), 0);
  const totalProfit   = filtered.reduce((s, t) => s + (t.realProfit || 0), 0);
  const avgProfit     = filtered.length ? totalProfit / filtered.length : 0;
  const avgDaysHeld   = filtered.length
    ? filtered.reduce((s, t) => s + (t.daysHeld || 0), 0) / filtered.length
    : 0;

  // Best categories
  const byCategory = {};
  filtered.forEach(tx => {
    const cat = tx.category || 'general';
    if (!byCategory[cat]) byCategory[cat] = { profit: 0, count: 0 };
    byCategory[cat].profit += tx.realProfit || 0;
    byCategory[cat].count++;
  });

  return {
    period,
    deals:         filtered.length,
    totalSpent:    Math.round(totalSpent * 100) / 100,
    totalRevenue:  Math.round(totalRevenue * 100) / 100,
    totalProfit:   Math.round(totalProfit * 100) / 100,
    avgProfit:     Math.round(avgProfit * 100) / 100,
    avgDaysHeld:   Math.round(avgDaysHeld * 10) / 10,
    roi:           totalSpent > 0 ? Math.round((totalProfit / totalSpent) * 100) : 0,
    byCategory,
    goalProgress:  Math.min(Math.round((totalProfit / 1000) * 100), 100)
  };
}

module.exports = {
  getInventory, addToInventory, updateInventoryItem,
  markAsListed, markAsSold,
  getTransactions, getPnL
};
