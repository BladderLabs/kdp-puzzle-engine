// sources/_template.js
// Copy this file, rename it, fill in the details
// Add one line to config/settings.js sources array
// Nothing else changes anywhere in the system

const SOURCE_NAME = 'template'; // CHANGE THIS

async function scrape(keywords) {
  const results = [];

  for (const keyword of keywords) {
    try {

      // YOUR SCRAPING LOGIC HERE
      // Use Apify actor, direct HTTP, official API — whatever works
      // Example using Apify:
      /*
      const res = await axios.post(
        `https://api.apify.com/v2/acts/YOUR_ACTOR_ID/runs`,
        { searchText: keyword, maxItems: 30 },
        { params: { token: process.env.APIFY_TOKEN } }
      );
      */

      // ALWAYS push items in this exact format
      // Engine expects this shape — never change the field names
      results.push(standardise({
        title:   'Item title here',
        price:   0,
        photos:  0,
        desc:    'Description text',
        url:     'https://...',
        keyword
      }));

    } catch (err) {
      console.error(`[${SOURCE_NAME}] "${keyword}":`, err.message);
    }
  }

  return results;
}

// DO NOT CHANGE THIS FUNCTION SIGNATURE
// Always return the same shape
function standardise(raw) {
  return {
    source:        SOURCE_NAME,      // never change
    title:         raw.title  || '', // item title
    askingPrice:   raw.price  || 0,  // buy price
    photoCount:    raw.photos || 0,  // number of photos
    descWordCount: (raw.desc  || '').split(' ').filter(Boolean).length,
    daysListed:    raw.days   || 0,  // how long it's been listed
    condition:     raw.condition || '',
    category:      raw.keyword || 'general',
    location:      'UK',
    url:           raw.url    || '',
    isAuction:     false,            // true for auction sites
    foundAt:       new Date().toISOString()
  };
}

module.exports = { scrape, SOURCE_NAME };
