// scrapers/vinted.js — Vinted clothing arbitrage scraper
const axios = require('axios');

const CLOTHING_KEYWORDS = process.env.VINTED_KEYWORDS
  ? process.env.VINTED_KEYWORDS.split(',')
  : ['ralph lauren', 'stone island', 'north face', 'nike air max', 'adidas', 'levi', 'carhartt'];

async function scrapeVinted() {
  const results = [];

  for (const keyword of CLOTHING_KEYWORDS) {
    try {
      const url = `https://www.vinted.co.uk/api/v2/catalog/items`;
      const res = await axios.get(url, {
        params: {
          search_text: keyword,
          per_page: 30,
          order: 'newest_first',
          currency: 'GBP'
        },
        headers: {
          'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15',
          'Accept': 'application/json',
          'Accept-Language': 'en-GB',
          'x-money-object': 'true'
        },
        timeout: 10000
      });

      const items = res.data?.items || [];

      for (const item of items) {
        const price = parseFloat(item.price?.amount || item.price || 0);
        const photos = item.photos?.length || 0;
        const title = item.title || '';
        const brand = item.brand_title || '';
        const condition = item.status || '';

        if (price > 0 && price < 200 && title) {
          results.push({
            source: 'vinted',
            title: `${brand} ${title}`.trim(),
            askingPrice: price,
            photoCount: photos,
            descWordCount: title.split(' ').length,
            daysListed: 0,
            category: 'clothing',
            condition,
            brand,
            url: `https://www.vinted.co.uk/items/${item.id}`,
            foundAt: new Date().toISOString()
          });
        }
      }
    } catch (err) {
      console.error(`Vinted scrape error for "${keyword}":`, err.message);
    }

    await sleep(1500);
  }

  return results;
}

const sleep = ms => new Promise(r => setTimeout(r, ms));

module.exports = { scrapeVinted };
