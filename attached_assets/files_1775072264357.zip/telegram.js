// alerts/telegram.js
// Telegram bot alerts — instant deal notifications

const axios = require('axios');

const TOKEN   = process.env.TELEGRAM_BOT_TOKEN;
const CHAT_ID = process.env.TELEGRAM_CHAT_ID;

// ─── SEND DEAL ALERT ─────────────────────────────────────────────────────────
async function sendDealAlert(deal) {
  if (!isConfigured()) return;

  const emoji    = deal.verdict === 'ELITE' ? '⚡' : '🔥';
  const urgency  = deal.isAuction && deal.hoursLeft < 6
    ? `\n⏰ ENDING IN ${Math.round(deal.hoursLeft)}h` : '';

  const msg = `${emoji} ${deal.verdict} DEAL [${deal.total}/100]

📦 ${deal.title}
💰 Buy: £${deal.askingPrice} → Sell: £${deal.profit?.sellPrice || '?'}
📈 Profit: £${deal.profit?.netProfit || '?'} | ROI: ${deal.profit?.roi || '?'}%
📉 ${deal.belowMarketPct || 0}% below market
⚡ Avg sell: ${deal.daysToSell || '?'} days
🏪 Source: ${deal.source}${urgency}
🔗 ${deal.url}`;

  await send(msg);
}

// ─── SEND AUCTION ALERT ──────────────────────────────────────────────────────
async function sendAuctionAlert(deal) {
  if (!isConfigured()) return;

  const msg = `⏰ AUCTION ENDING SOON

📦 ${deal.title}
💰 Current bid: £${deal.askingPrice}
🎯 Max bid: £${deal.maxBid || '?'}
📈 If won: £${deal.profit?.netProfit || '?'} profit
⏱ Ends in: ${deal.hoursLeft < 1 ? '<1 hour' : Math.round(deal.hoursLeft) + ' hours'}
🔗 ${deal.url}`;

  await send(msg);
}

// ─── SEND SCAN SUMMARY ───────────────────────────────────────────────────────
async function sendScanSummary(stats) {
  if (!isConfigured()) return;

  const msg = `📊 Scan Complete

✅ New deals found: ${stats.newDeals}
⚡ Elite: ${stats.elite} | 🔥 Hot: ${stats.hot} | 👍 Good: ${stats.good}
📡 Sources scanned: ${stats.sources?.join(', ') || 'all'}
⏱ Next scan in 20 mins`;

  await send(msg);
}

// ─── SEND P&L UPDATE ─────────────────────────────────────────────────────────
async function sendPnLUpdate(pnl) {
  if (!isConfigured()) return;

  const bar     = '█'.repeat(Math.floor(pnl.goalProgress / 10)) + '░'.repeat(10 - Math.floor(pnl.goalProgress / 10));
  const msg = `💼 Monthly P&L Update

${bar} ${pnl.goalProgress}%
🎯 Goal: £1,000 | Earned: £${pnl.totalProfit}

📦 Deals sold: ${pnl.deals}
💰 Revenue: £${pnl.totalRevenue}
📈 Avg profit/deal: £${pnl.avgProfit}
⏱ Avg days to sell: ${pnl.avgDaysHeld}`;

  await send(msg);
}

// ─── CORE SEND ───────────────────────────────────────────────────────────────
async function send(text) {
  if (!isConfigured()) {
    console.log('[Telegram] Not configured — skipping alert');
    return;
  }

  try {
    await axios.post(
      `https://api.telegram.org/bot${TOKEN}/sendMessage`,
      { chat_id: CHAT_ID, text, parse_mode: 'Markdown' },
      { timeout: 5000 }
    );
  } catch (err) {
    console.error('[Telegram] Send error:', err.message);
  }
}

function isConfigured() {
  return TOKEN && TOKEN !== 'your_telegram_bot_token_here'
    && CHAT_ID && CHAT_ID !== 'your_telegram_chat_id_here';
}

module.exports = { sendDealAlert, sendAuctionAlert, sendScanSummary, sendPnLUpdate, send };
