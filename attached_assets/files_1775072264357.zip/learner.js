// intelligence/learner.js
// Self-learning layer — adjusts scoring based on your real outcomes
// Gets smarter with every deal you complete

const fs   = require('fs');
const path = require('path');

const MULTIPLIERS_PATH   = path.join(__dirname, '../db/multipliers.json');
const PREDICTIONS_PATH   = path.join(__dirname, '../db/predictions.json');

// ─── LOAD MULTIPLIERS ────────────────────────────────────────────────────────
function getMultipliers() {
  try {
    return JSON.parse(fs.readFileSync(MULTIPLIERS_PATH, 'utf8'));
  } catch {
    return {};
  }
}

// ─── APPLY MULTIPLIERS TO ITEM ───────────────────────────────────────────────
function applyMultipliers(item, market) {
  const multipliers = getMultipliers();
  const key         = buildKey(item.category, item.source);
  const multiplier  = multipliers[key]?.profitMultiplier || 1.0;
  const speedBonus  = multipliers[key]?.speedBonus || 0;

  return {
    ...market,
    daysToSell:        Math.max(0, market.daysToSell - speedBonus),
    _multiplierKey:    key,
    _multiplierValue:  multiplier,
    _speedBonus:       speedBonus
  };
}

// ─── LOG PREDICTION ──────────────────────────────────────────────────────────
function logPrediction(dealId, predictedProfit, predictedDays, score) {
  const predictions = loadPredictions();
  predictions[dealId] = {
    predictedProfit,
    predictedDays,
    score,
    loggedAt: new Date().toISOString()
  };
  fs.writeFileSync(PREDICTIONS_PATH, JSON.stringify(predictions, null, 2));
}

// ─── LOG OUTCOME ─────────────────────────────────────────────────────────────
function logOutcome(dealId, realProfit, realDays, category, source) {
  const predictions = loadPredictions();
  const prediction  = predictions[dealId];

  if (!prediction) return;

  // Record outcome
  prediction.realProfit  = realProfit;
  prediction.realDays    = realDays;
  prediction.category    = category;
  prediction.source      = source;
  prediction.resolvedAt  = new Date().toISOString();
  prediction.profitDelta = realProfit - prediction.predictedProfit;
  prediction.daysDelta   = realDays - prediction.predictedDays;

  fs.writeFileSync(PREDICTIONS_PATH, JSON.stringify(predictions, null, 2));

  // Update multipliers after every 10 resolved deals
  const resolved = Object.values(predictions).filter(p => p.realProfit !== undefined);
  if (resolved.length % 10 === 0) {
    recalculateMultipliers(resolved);
  }
}

// ─── RECALCULATE MULTIPLIERS ─────────────────────────────────────────────────
function recalculateMultipliers(resolvedDeals) {
  const grouped = {};

  // Group by category + source
  resolvedDeals.forEach(deal => {
    if (!deal.category || !deal.source) return;
    const key = buildKey(deal.category, deal.source);
    if (!grouped[key]) grouped[key] = [];
    grouped[key].push(deal);
  });

  const multipliers = getMultipliers();

  Object.entries(grouped).forEach(([key, deals]) => {
    if (deals.length < 5) return; // Need at least 5 data points

    // Profit multiplier — how accurate were our profit predictions?
    const profitRatios = deals
      .filter(d => d.predictedProfit > 0)
      .map(d => d.realProfit / d.predictedProfit);

    const avgRatio = profitRatios.reduce((s, r) => s + r, 0) / profitRatios.length;

    // Speed bonus — how many days faster/slower than eBay average?
    const speedDeltas = deals
      .filter(d => d.daysDelta !== undefined)
      .map(d => -d.daysDelta); // negative delta = sold faster than predicted

    const avgSpeedBonus = speedDeltas.length
      ? speedDeltas.reduce((s, d) => s + d, 0) / speedDeltas.length
      : 0;

    multipliers[key] = {
      profitMultiplier: Math.round(avgRatio * 100) / 100,
      speedBonus:       Math.round(avgSpeedBonus * 10) / 10,
      sampleSize:       deals.length,
      lastUpdated:      new Date().toISOString()
    };

    console.log(`[Learner] Updated multipliers for ${key}:`, multipliers[key]);
  });

  fs.writeFileSync(MULTIPLIERS_PATH, JSON.stringify(multipliers, null, 2));
}

// ─── GET LEARNING REPORT ─────────────────────────────────────────────────────
function getLearningReport() {
  const multipliers = getMultipliers();
  const predictions = loadPredictions();
  const resolved    = Object.values(predictions).filter(p => p.realProfit !== undefined);

  return {
    totalDealsTracked:  Object.keys(predictions).length,
    totalResolved:      resolved.length,
    categoriesLearned:  Object.keys(multipliers).length,
    multipliers,
    accuracy: resolved.length > 0
      ? Math.round(
          resolved.reduce((s, d) => s + Math.abs(d.profitDelta / d.predictedProfit), 0)
          / resolved.length * 100
        )
      : null
  };
}

// ─── HELPERS ─────────────────────────────────────────────────────────────────
function buildKey(category, source) {
  return `${(category || 'general').toLowerCase().replace(/\s/g, '_')}_${(source || 'unknown').toLowerCase()}`;
}

function loadPredictions() {
  try {
    return JSON.parse(fs.readFileSync(PREDICTIONS_PATH, 'utf8'));
  } catch {
    return {};
  }
}

module.exports = { applyMultipliers, logPrediction, logOutcome, getLearningReport, getMultipliers };
