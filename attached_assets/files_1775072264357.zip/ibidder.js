// scrapers/ibidder.js — i-bidder.com auction scraper
const axios = require('axios');
const cheerio = require('cheerio');

const KEYWORDS = process.env.SEARCH_KEYWORDS
  ? process.env.SEARCH_KEYWORDS.split(',')
  : ['electronics', 'tools', 'camera', 'laptop', 'watches', 'collectibles'];

async function scrapeIbidder() {
  const results = [];

  for (const keyword of KEYWORDS) {
    try {
      const url = `https://www.i-bidder.com/en-gb/auction-catalogues/search?q=${encodeURIComponent(keyword)}&sortby=enddate_asc`;
      const res = await axios.get(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36',
          'Accept-Language': 'en-GB,en;q=0.9'
        },
        timeout: 10000
      });

      const $ = cheerio.load(res.data);

      $('.lot-card, .lot-item, [class*="lot"]').each((i, el) => {
        const title = $(el).find('[class*="title"], h2, h3').first().text().trim();
        const priceText = $(el).find('[class*="price"], [class*="bid"]').first().text().trim();
        const price = parseFloat(priceText.replace(/[^0-9.]/g, '')) || 0;
        const photos = $(el).find('img').length;
        const desc = $(el).find('[class*="desc"], p').first().text().trim();
        const endTime = $(el).find('[class*="time"], [class*="end"]').first().text().trim();
        const link = $(el).find('a').first().attr('href');

        if (title && price > 0 && price < 500) {
          results.push({
            source: 'ibidder',
            title,
            askingPrice: price,
            photoCount: photos,
            descWordCount: desc.split(' ').length,
            endTime,
            category: keyword,
            url: link ? `https://www.i-bidder.com${link}` : url,
            daysListed: 0,
            foundAt: new Date().toISOString()
          });
        }
      });
    } catch (err) {
      console.error(`i-bidder scrape error for "${keyword}":`, err.message);
    }

    await sleep(1500); // polite delay
  }

  return results;
}

const sleep = ms => new Promise(r => setTimeout(r, ms));

module.exports = { scrapeIbidder };
