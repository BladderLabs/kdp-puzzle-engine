// server.js — Arbitrage Engine Core
require('dotenv').config();
const express = require('express');
const cron = require('node-cron');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

const { getEbaySoldData } = require('./scrapers/ebay');
const { scrapeIbidder } = require('./scrapers/ibidder');
const { scrapeGumtree } = require('./scrapers/gumtree');
const { scrapeVinted } = require('./scrapers/vinted');
const { scoreItem } = require('./engine/scorer');

const app = express();
const PORT = process.env.PORT || 3000;
const DB_PATH = path.join(__dirname, 'db', 'deals.json');

// Ensure DB dir exists
if (!fs.existsSync(path.join(__dirname, 'db'))) {
  fs.mkdirSync(path.join(__dirname, 'db'));
}
if (!fs.existsSync(DB_PATH)) {
  fs.writeFileSync(DB_PATH, JSON.stringify([]));
}

app.use(express.static('public'));
app.use(express.json());

// --- API Routes ---

app.get('/api/deals', (req, res) => {
  const deals = loadDeals();
  const { min, source, sort } = req.query;
  let filtered = deals;

  if (min) filtered = filtered.filter(d => d.score >= parseInt(min));
  if (source) filtered = filtered.filter(d => d.source === source);
  if (sort === 'profit') filtered.sort((a, b) => b.netProfit - a.netProfit);
  else filtered.sort((a, b) => b.score - a.score);

  res.json({ deals: filtered, total: filtered.length, lastScan: getLastScan() });
});

app.get('/api/stats', (req, res) => {
  const deals = loadDeals();
  const hot = deals.filter(d => d.score >= 80).length;
  const good = deals.filter(d => d.score >= 65 && d.score < 80).length;
  const avgProfit = deals.length
    ? (deals.reduce((s, d) => s + d.netProfit, 0) / deals.length).toFixed(2)
    : 0;
  const sources = [...new Set(deals.map(d => d.source))];
  res.json({ total: deals.length, hot, good, avgProfit, sources });
});

app.delete('/api/deals/:id', (req, res) => {
  let deals = loadDeals();
  deals = deals.filter(d => d.id !== req.params.id);
  saveDeals(deals);
  res.json({ ok: true });
});

app.post('/api/scan', async (req, res) => {
  res.json({ ok: true, message: 'Scan started' });
  runScan(); // fire and forget
});

// --- Core Scan Function ---
async function runScan() {
  console.log(`\n[${new Date().toLocaleTimeString()}] Starting scan...`);
  const allItems = [];

  try {
    const [ibidderItems, gumtreeItems, vintedItems] = await Promise.allSettled([
      scrapeIbidder(),
      scrapeGumtree(),
      scrapeVinted()
    ]);

    if (ibidderItems.status === 'fulfilled') allItems.push(...ibidderItems.value);
    if (gumtreeItems.status === 'fulfilled') allItems.push(...gumtreeItems.value);
    if (vintedItems.status === 'fulfilled')  allItems.push(...vintedItems.value);

    console.log(`Found ${allItems.length} raw items across all sources`);
  } catch (err) {
    console.error('Scrape error:', err.message);
  }

  const scoredDeals = [];

  for (const item of allItems) {
    try {
      const ebayData = await getEbaySoldData(cleanTitle(item.title));
      if (!ebayData) continue;

      const scoring = scoreItem(item, ebayData);
      if (!scoring || scoring.score < 65) continue;

      const deal = {
        id: `${item.source}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        ...item,
        ...scoring,
        scannedAt: new Date().toISOString()
      };

      scoredDeals.push(deal);

      if (scoring.score >= 80) {
        await sendTelegramAlert(deal);
      }

      await sleep(500); // rate limit eBay API calls
    } catch (err) {
      console.error(`Scoring error for "${item.title}":`, err.message);
    }
  }

  // Merge with existing, deduplicate by URL, keep last 500
  let existing = loadDeals();
  const existingUrls = new Set(existing.map(d => d.url));
  const newDeals = scoredDeals.filter(d => !existingUrls.has(d.url));
  const merged = [...newDeals, ...existing].slice(0, 500);
  saveDeals(merged);

  fs.writeFileSync(
    path.join(__dirname, 'db', 'last_scan.json'),
    JSON.stringify({ time: new Date().toISOString(), found: newDeals.length })
  );

  console.log(`Scan complete. ${newDeals.length} new deals saved. ${scoredDeals.filter(d => d.score >= 80).length} HOT deals.`);
}

// --- Telegram Alert ---
async function sendTelegramAlert(deal) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;
  if (!token || !chatId) return;

  const msg = `🔥 HOT DEAL [${deal.score}/100]
📦 ${deal.title}
💰 Buy: £${deal.askingPrice} → Sell: £${deal.avgSoldPrice}
📈 Profit: £${deal.netProfit} (${deal.belowMarketPct}% below market)
⚡ Avg sell time: ${deal.daysToSell} days
🔗 ${deal.url}`;

  try {
    await axios.post(`https://api.telegram.org/bot${token}/sendMessage`, {
      chat_id: chatId,
      text: msg,
      parse_mode: 'Markdown'
    });
  } catch (err) {
    console.error('Telegram error:', err.message);
  }
}

// --- Helpers ---
function loadDeals() {
  try { return JSON.parse(fs.readFileSync(DB_PATH, 'utf8')); }
  catch { return []; }
}
function saveDeals(deals) {
  fs.writeFileSync(DB_PATH, JSON.stringify(deals, null, 2));
}
function getLastScan() {
  try {
    return JSON.parse(fs.readFileSync(path.join(__dirname, 'db', 'last_scan.json'), 'utf8'));
  } catch { return null; }
}
function cleanTitle(title) {
  return title.replace(/[^a-zA-Z0-9 ]/g, '').substring(0, 60).trim();
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

// --- Scheduler: every 20 minutes ---
cron.schedule('*/20 * * * *', () => {
  console.log('Scheduled scan triggered');
  runScan();
});

// --- Start ---
app.listen(PORT, () => {
  console.log(`Arbitrage Engine running on port ${PORT}`);
  console.log(`Dashboard: http://localhost:${PORT}`);
  runScan(); // immediate first scan on startup
});
