// ══════════════════════════════════════════════════════════════════
// KDP PUZZLE ENGINE v5 — Unified Edition
// One tool: generates interior PDF + cover PDF, ready for KDP upload
//
// SETUP: npm install → node server.js → open in browser
// ══════════════════════════════════════════════════════════════════

const express = require('express');
const puppeteer = require('puppeteer');
const app = express();
app.use(express.json({ limit: '50mb' }));

// ══════════════════════════════════════
// PUZZLE GENERATORS (server-side)
// ══════════════════════════════════════

function shuf(a) {
  const b = [...a];
  for (let i = b.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [b[i], b[j]] = [b[j], b[i]];
  }
  return b;
}

function makeWordSearch(words, size) {
  const grid = Array.from({ length: size }, () => Array(size).fill(''));
  const DIRS = [[0,1],[0,-1],[1,0],[-1,0],[1,1],[1,-1],[-1,1],[-1,-1]];
  const placed = [], pSet = {};
  const sorted = [...words].sort((a, b) => b.length - a.length);

  for (const word of sorted) {
    if (word.length > size) continue;
    let done = false;
    for (const [dr, dc] of shuf(DIRS)) {
      if (done) break;
      for (const [sr, sc] of shuf(Array.from({ length: size * size }, (_, i) => [Math.floor(i / size), i % size]))) {
        let ok = true;
        for (let k = 0; k < word.length; k++) {
          const nr = sr + dr * k, nc = sc + dc * k;
          if (nr < 0 || nr >= size || nc < 0 || nc >= size) { ok = false; break; }
          if (grid[nr][nc] !== '' && grid[nr][nc] !== word[k]) { ok = false; break; }
        }
        if (ok) {
          for (let k = 0; k < word.length; k++) {
            const nr = sr + dr * k, nc = sc + dc * k;
            grid[nr][nc] = word[k];
            pSet[nr + ',' + nc] = true;
          }
          placed.push(word);
          done = true;
          break;
        }
      }
    }
  }
  for (let r = 0; r < size; r++)
    for (let c = 0; c < size; c++)
      if (grid[r][c] === '') grid[r][c] = String.fromCharCode(65 + Math.floor(Math.random() * 26));
  return { grid, placed, pSet };
}

function makeSudoku(diff) {
  const holes = diff === 'Easy' ? 32 : diff === 'Hard' ? 50 : 44;
  const board = Array.from({ length: 9 }, () => Array(9).fill(0));

  function ok(b, r, c, n) {
    for (let i = 0; i < 9; i++) if (b[r][i] === n || b[i][c] === n) return false;
    const br = Math.floor(r / 3) * 3, bc = Math.floor(c / 3) * 3;
    for (let i = br; i < br + 3; i++) for (let j = bc; j < bc + 3; j++) if (b[i][j] === n) return false;
    return true;
  }
  function fill(b) {
    for (let r = 0; r < 9; r++) for (let c = 0; c < 9; c++) {
      if (b[r][c] === 0) {
        for (const n of shuf([1,2,3,4,5,6,7,8,9])) {
          if (ok(b, r, c, n)) { b[r][c] = n; if (fill(b)) return true; b[r][c] = 0; }
        }
        return false;
      }
    }
    return true;
  }
  fill(board);
  const solution = board.map(r => [...r]), puzzle = board.map(r => [...r]);
  function cnt(b, lim) {
    for (let r = 0; r < 9; r++) for (let c = 0; c < 9; c++) {
      if (b[r][c] === 0) {
        let ct = 0;
        for (let n = 1; n <= 9; n++) {
          if (ok(b, r, c, n)) { b[r][c] = n; ct += cnt(b, lim - ct); b[r][c] = 0; if (ct >= lim) return ct; }
        }
        return ct;
      }
    }
    return 1;
  }
  let rem = 0;
  for (const idx of shuf(Array.from({ length: 81 }, (_, i) => i))) {
    if (rem >= holes) break;
    const r = Math.floor(idx / 9), c = idx % 9;
    if (puzzle[r][c] === 0) continue;
    const bk = puzzle[r][c];
    puzzle[r][c] = 0;
    if (cnt(puzzle.map(r => [...r]), 2) === 1) rem++;
    else puzzle[r][c] = bk;
  }
  return { puzzle, solution };
}

const DEFWORDS = 'PUZZLE,SEARCH,WORDS,BRAIN,THINK,SOLVE,GAME,PLAY,FIND,HIDDEN,LETTER,GRID,CLUE,ANSWER,MATCH,LEVEL,SCORE,BONUS,TIMER,CHALLENGE,FOCUS,RELAX,SHARP,MIND'.split(',');

// ══════════════════════════════════════
// HTML BUILDERS
// ══════════════════════════════════════

function gutterIn(p) { return p <= 150 ? 0.375 : p <= 300 ? 0.5 : p <= 500 ? 0.625 : 0.75; }

function buildInteriorHTML(opts) {
  const T = opts.title, ST = opts.subtitle || '', PT = opts.puzzleType || 'Word Search';
  const PC = parseInt(opts.puzzleCount) || 100, DF = opts.difficulty || 'Medium';
  const LP = opts.largePrint !== false;
  const isWS = PT === 'Word Search';
  const yr = new Date().getFullYear();
  const vol = opts.series === '3-Volume' ? 'Volume 1 of 3' : '';
  const wpp = LP ? 16 : 20, gsz = LP ? 13 : 15;
  const wC = LP ? 32 : 27, wF = LP ? 16 : 13;
  const sC = LP ? 50 : 44, sF = LP ? 22 : 18;

  const wordBank = (opts.words && opts.words.length >= 10) ? opts.words : DEFWORDS;
  const puzzles = [];
  for (let i = 0; i < PC; i++) {
    if (isWS) puzzles.push(makeWordSearch(shuf(wordBank).slice(0, Math.min(wordBank.length, wpp)), gsz));
    else puzzles.push(makeSudoku(DF));
  }

  const aPer = isWS ? (LP ? 9 : 12) : (LP ? 6 : 8);
  const aP = Math.ceil(PC / aPer), totP = 3 + PC + aP;
  const gut = Math.max(0.5, gutterIn(totP));
  const pS = 5, aS = pS + PC;

  let html = `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>${T}</title>` +
    `<link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,700;1,400&family=Source+Code+Pro:wght@400;600&display=swap" rel="stylesheet">` +
    `<style>*{margin:0;padding:0;box-sizing:border-box;}@page{size:8.5in 11in;margin:0;}` +
    `.pg{width:8.5in;min-height:11in;page-break-after:always;position:relative;overflow:hidden;}` +
    `.pg:last-child{page-break-after:auto;}` +
    `.in{padding:0.55in 0.4in 0.6in ${gut}in;background:#fff;}` +
    `.hd{display:flex;justify-content:space-between;font-family:'Source Code Pro',monospace;font-size:8px;color:#aaa;border-bottom:1px solid #e0e0e0;padding-bottom:4px;margin-bottom:8px;}` +
    `.ft{position:absolute;bottom:0.25in;left:${gut}in;right:0.4in;display:flex;justify-content:space-between;font-family:'Source Code Pro',monospace;font-size:9px;color:#bbb;border-top:1px solid #e0e0e0;padding-top:4px;}` +
    `</style></head><body>`;

  // Title page
  html += `<div class="pg in"><div style="display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:9in;text-align:center;">` +
    `<div style="font-family:'Source Code Pro',monospace;font-size:10px;letter-spacing:4px;color:#888;text-transform:uppercase;margin-bottom:20px;">${PT} Collection</div>` +
    `<div style="font-family:Lora,serif;font-size:34px;font-weight:700;color:#222;margin-bottom:10px;">${T}</div>` +
    `<div style="font-family:Lora,serif;font-size:15px;font-style:italic;color:#666;margin-bottom:24px;">${ST}</div>` +
    `<div style="width:56px;height:1px;background:#ccc;margin-bottom:20px;"></div>` +
    `<div style="font-family:'Source Code Pro',monospace;font-size:9px;color:#999;line-height:2;">` +
    `&copy; ${yr} All Rights Reserved &middot; Published via Amazon KDP<br/>Puzzle content generated with AI assistance${vol ? '<br/>' + vol : ''}</div>` +
    (opts.author ? `<div style="font-family:Lora,serif;font-size:12px;color:#888;margin-top:12px;">${opts.author}</div>` : '') +
    `</div></div>`;

  // How to play
  const htxt = isWS ? 'Each puzzle contains a grid of letters with hidden words. Words can run horizontally, vertically, or diagonally — both forward and backward. Find every word in the bank below each grid.' : 'Fill empty cells so every row, column, and 3&times;3 box contains digits 1-9 exactly once.';
  const tip = isWS ? 'Scan for uncommon letters like Q, Z, X first.' : 'Write small pencil marks for candidates.';
  html += `<div class="pg in"><div class="hd"><span>${T}</span><span>${DF} &middot; ${PT}</span></div>` +
    `<div style="padding-top:0.3in;"><div style="font-family:Lora,serif;font-size:26px;font-weight:700;color:#222;margin-bottom:12px;">How to Play</div>` +
    `<div style="width:56px;height:2px;background:#333;margin-bottom:20px;"></div>` +
    `<div style="font-family:Lora,serif;font-size:13px;line-height:1.8;color:#333;margin-bottom:28px;">${htxt}</div>` +
    `<div style="border-left:3px solid #333;background:#f9f9f6;padding:14px 18px;">` +
    `<div style="font-family:'Source Code Pro',monospace;font-size:10px;letter-spacing:3px;color:#333;font-weight:600;margin-bottom:6px;">TIP</div>` +
    `<div style="font-family:Lora,serif;font-size:12px;color:#444;">${tip}</div></div>` +
    (LP ? '<div style="margin-top:20px;font-family:Source Code Pro,monospace;font-size:10px;letter-spacing:2px;color:#888;text-align:center;">LARGE PRINT EDITION</div>' : '') +
    `</div><div class="ft"><span>${T}</span><span>3</span></div></div>`;

  // TOC
  let tocR = '';
  const mx = Math.min(PC, 42);
  for (let i = 0; i < mx; i++) tocR += `<div style="display:flex;justify-content:space-between;font-family:'Source Code Pro',monospace;font-size:11px;color:#555;padding:2px 0;border-bottom:1px dotted #ddd;"><span>Puzzle #${String(i + 1).padStart(2, '0')}</span><span>${pS + i}</span></div>`;
  if (PC > 42) tocR += `<div style="font-family:Lora,serif;font-size:11px;color:#888;padding:6px 0;font-style:italic;">&hellip; and ${PC - 42} more</div>`;
  html += `<div class="pg in"><div class="hd"><span>${T}</span><span>${DF} &middot; ${PT}</span></div>` +
    `<div style="padding-top:0.3in;"><div style="font-family:Lora,serif;font-size:26px;font-weight:700;color:#222;margin-bottom:16px;">Table of Contents</div>` +
    `<div style="columns:2;column-gap:32px;">${tocR}</div>` +
    `<div style="margin-top:20px;font-family:'Source Code Pro',monospace;font-size:10px;color:#333;letter-spacing:2px;font-weight:600;">ANSWER KEY &mdash; PAGE ${aS}</div></div>` +
    `<div class="ft"><span>${T}</span><span>4</span></div></div>`;

  // Puzzle pages
  for (let i = 0; i < PC; i++) {
    const pN = pS + i, lb = '#' + String(i + 1).padStart(2, '0');
    if (isWS) {
      const { grid, placed } = puzzles[i];
      let g = '<table style="border-collapse:collapse;margin:10px auto;">';
      for (let r = 0; r < grid.length; r++) {
        g += '<tr>';
        for (let c = 0; c < grid[r].length; c++)
          g += `<td style="width:${wC}px;height:${wC}px;text-align:center;vertical-align:middle;font-family:'Source Code Pro',monospace;font-size:${wF}px;font-weight:500;color:#333;border:1px solid #ddd;">${grid[r][c]}</td>`;
        g += '</tr>';
      }
      g += '</table>';
      const ch = placed.map(w => `<span style="display:inline-block;font-family:'Source Code Pro',monospace;font-size:${LP ? 11 : 10}px;background:#f5f3ee;border:1px solid #ddd;border-radius:3px;padding:3px 8px;margin:2px;">${w}</span>`).join('');
      html += `<div class="pg in"><div class="hd"><span>${T}</span><span>${DF} &middot; Word Search</span></div><div style="padding-top:0.15in;"><div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:6px;"><span style="font-family:'Source Code Pro',monospace;font-size:12px;font-weight:600;color:#333;">${lb}</span><span style="font-family:'Source Code Pro',monospace;font-size:9px;letter-spacing:2px;color:#aaa;">WORD SEARCH &middot; ${DF.toUpperCase()}</span></div>${g}<div style="text-align:center;margin-top:8px;">${ch}</div></div><div class="ft"><span>${T}</span><span>${pN}</span></div></div>`;
    } else {
      const { puzzle: pz } = puzzles[i];
      let g = '<table style="border-collapse:collapse;margin:16px auto;">';
      for (let r = 0; r < 9; r++) {
        g += '<tr>';
        for (let c = 0; c < 9; c++) {
          const v = pz[r][c];
          let bR = (c === 2 || c === 5) ? '2.5px solid #333' : '1px solid #bbb';
          let bB = (r === 2 || r === 5) ? '2.5px solid #333' : '1px solid #bbb';
          const bT = r === 0 ? '2.5px solid #333' : 'none';
          const bL = c === 0 ? '2.5px solid #333' : 'none';
          if (c === 8) bR = '2.5px solid #333';
          if (r === 8) bB = '2.5px solid #333';
          const cs = v ? 'color:#111;font-weight:700;background:#f5f5f0;' : 'color:#fff;';
          g += `<td style="width:${sC}px;height:${sC}px;text-align:center;vertical-align:middle;font-family:'Source Code Pro',monospace;font-size:${sF}px;${cs}border-right:${bR};border-bottom:${bB};border-top:${bT};border-left:${bL};">${v || ''}</td>`;
        }
        g += '</tr>';
      }
      g += '</table>';
      html += `<div class="pg in"><div class="hd"><span>${T}</span><span>${DF} &middot; Sudoku</span></div><div style="padding-top:0.15in;"><div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:6px;"><span style="font-family:'Source Code Pro',monospace;font-size:12px;font-weight:600;color:#333;">${lb}</span><span style="font-family:'Source Code Pro',monospace;font-size:9px;letter-spacing:2px;color:#aaa;">SUDOKU &middot; ${DF.toUpperCase()}</span></div>${g}</div><div class="ft"><span>${T}</span><span>${pN}</span></div></div>`;
    }
  }

  // Answer key
  let akP = aS;
  if (isWS) {
    for (let p = 0; p < PC; p += aPer) {
      const batch = puzzles.slice(p, p + aPer);
      let gs = '<div style="display:flex;flex-wrap:wrap;gap:14px;justify-content:center;">';
      batch.forEach((ws, idx) => {
        const cSz = LP ? 9 : 8, fSz = LP ? 6 : 5;
        let m = `<div style="text-align:center;"><div style="font-family:'Source Code Pro',monospace;font-size:8px;color:#666;font-weight:600;">#${String(p + idx + 1).padStart(2, '0')}</div><table style="border-collapse:collapse;">`;
        for (let r = 0; r < ws.grid.length; r++) {
          m += '<tr>';
          for (let c = 0; c < ws.grid[r].length; c++) {
            const ia = ws.pSet[r + ',' + c];
            m += `<td style="width:${cSz}px;height:${cSz}px;font-size:${fSz}px;text-align:center;font-family:monospace;color:${ia ? '#000' : '#ccc'};font-weight:${ia ? '700' : '400'};${ia ? 'background:#e0e0d8;' : ''}border:1px solid #eee;">${ws.grid[r][c]}</td>`;
          }
          m += '</tr>';
        }
        m += '</table></div>';
        gs += m;
      });
      gs += '</div>';
      html += `<div class="pg in"><div class="hd"><span>Answer Key</span><span>Word Search</span></div><div style="padding-top:0.2in;">${gs}</div><div class="ft"><span>${T}</span><span>${akP}</span></div></div>`;
      akP++;
    }
  } else {
    for (let p = 0; p < PC; p += aPer) {
      const batch = puzzles.slice(p, p + aPer);
      const cSz = LP ? 16 : 14;
      let gs = '<div style="display:flex;flex-wrap:wrap;gap:16px;justify-content:center;">';
      batch.forEach((sd, idx) => {
        let m = `<div style="text-align:center;"><div style="font-family:'Source Code Pro',monospace;font-size:8px;color:#666;font-weight:600;">#${String(p + idx + 1).padStart(2, '0')}</div><table style="border-collapse:collapse;">`;
        for (let r = 0; r < 9; r++) {
          m += '<tr>';
          for (let c = 0; c < 9; c++) {
            let bR = (c === 2 || c === 5) ? '2px solid #555' : '1px solid #ddd';
            let bB = (r === 2 || r === 5) ? '2px solid #555' : '1px solid #ddd';
            const bT = r === 0 ? '2px solid #555' : 'none';
            const bL = c === 0 ? '2px solid #555' : 'none';
            if (c === 8) bR = '2px solid #555';
            if (r === 8) bB = '2px solid #555';
            m += `<td style="width:${cSz}px;height:${cSz}px;font-size:${cSz - 6}px;text-align:center;font-family:monospace;color:#333;border-right:${bR};border-bottom:${bB};border-top:${bT};border-left:${bL};">${sd.solution[r][c]}</td>`;
          }
          m += '</tr>';
        }
        m += '</table></div>';
        gs += m;
      });
      gs += '</div>';
      html += `<div class="pg in"><div class="hd"><span>Answer Key</span><span>Sudoku</span></div><div style="padding-top:0.2in;">${gs}</div><div class="ft"><span>${T}</span><span>${akP}</span></div></div>`;
      akP++;
    }
  }

  html += '</body></html>';
  return { html, totalPages: totP };
}

// ── Cover HTML (full wrap) ──
function buildCoverHTML(opts, totalPages) {
  const THEMES = {
    midnight: { bg: '#0A0A14', ac: '#C8951A', tx: '#EDE8DC' },
    forest:   { bg: '#0A1208', ac: '#4A8A4A', tx: '#E0EDE0' },
    crimson:  { bg: '#140808', ac: '#C84A1A', tx: '#EDE0DC' },
    ocean:    { bg: '#080A14', ac: '#1A7AC8', tx: '#DCE4ED' },
    violet:   { bg: '#100814', ac: '#8A4AC8', tx: '#E4DCED' },
    slate:    { bg: '#0C0C0C', ac: '#C87A2A', tx: '#EDEBE6' },
  };
  const th = THEMES[opts.theme] || THEMES.midnight;
  const bg = opts.customBg || th.bg, ac = opts.customAccent || th.ac, tx = opts.customText || th.tx;
  const bleed = 0.125, trimW = 8.5, trimH = 11;
  const thick = opts.paperType === 'cream' ? 0.0025 : 0.002252;
  const spineW = totalPages * thick + 0.06;
  const fullW = bleed + trimW + spineW + trimW + bleed;
  const fullH = bleed + trimH + bleed;
  const spineX = bleed + trimW, frontX = spineX + spineW;

  const title = opts.title || 'Book Title';
  const sub = opts.subtitle || '';
  const author = opts.author || '';
  const meta = `${opts.puzzleCount || 100} ${opts.puzzleType || 'Word Search'} Puzzles | ${opts.difficulty || 'Medium'} | Large Print`;

  const deco = `<div style="position:absolute;top:12%;right:8%;width:120px;height:120px;border:2px solid ${ac}22;border-radius:50%;"></div>` +
    `<div style="position:absolute;bottom:15%;left:6%;width:80px;height:80px;border:2px solid ${ac}18;border-radius:50%;"></div>` +
    `<div style="position:absolute;top:35%;right:12%;width:50px;height:50px;border:1.5px solid ${ac}15;transform:rotate(45deg);"></div>`;

  // Back cover
  const backDesc = opts.backDescription || `Enjoy ${opts.puzzleCount || 100} carefully crafted puzzles. Large print formatting for comfortable solving. Complete answer key included.`;
  const back = `<div style="position:absolute;left:${bleed}in;top:${bleed}in;width:${trimW}in;height:${trimH}in;background:${bg};display:flex;flex-direction:column;align-items:center;justify-content:center;padding:1.5in 1in;text-align:center;box-sizing:border-box;">` +
    `<div style="font-family:Lora,serif;font-size:16px;color:${tx}cc;line-height:1.8;margin-bottom:40px;">${backDesc}</div>` +
    `<div style="width:50px;height:1px;background:${ac};margin-bottom:30px;"></div>` +
    (author ? `<div style="font-family:Lora,serif;font-size:12px;color:${tx}99;margin-bottom:12px;">${author}</div>` : '') +
    `<div style="font-family:'Source Code Pro',monospace;font-size:9px;letter-spacing:3px;color:${tx}88;">${meta}</div>` +
    `<div style="position:absolute;bottom:0.5in;right:0.4in;width:2in;height:1.2in;border:1px dashed ${ac}33;display:flex;align-items:center;justify-content:center;"><div style="font-family:'Source Code Pro',monospace;font-size:7px;color:${ac}55;">BARCODE AREA</div></div></div>`;

  // Spine
  const spine = spineW >= 0.2
    ? `<div style="position:absolute;left:${spineX}in;top:${bleed}in;width:${spineW}in;height:${trimH}in;background:${bg};display:flex;align-items:center;justify-content:center;"><div style="transform:rotate(-90deg);white-space:nowrap;font-family:'Source Code Pro',monospace;font-size:8px;letter-spacing:2px;color:${tx}bb;text-transform:uppercase;">${title}${author ? ' — ' + author : ''}</div></div>`
    : `<div style="position:absolute;left:${spineX}in;top:${bleed}in;width:${spineW}in;height:${trimH}in;background:${bg};"></div>`;

  // Front cover (classic style — reliable for all niches)
  const fb = `position:absolute;left:${frontX}in;top:${bleed}in;width:${trimW}in;height:${trimH}in;background:${bg};display:flex;flex-direction:column;align-items:center;justify-content:center;color:${tx};font-family:Lora,serif;box-sizing:border-box;overflow:hidden;`;
  const cs = opts.coverStyle || 'classic';

  let front = '';
  if (cs === 'luxury') {
    front = `<div style="${fb}padding:0;">${deco}<div style="position:absolute;top:0.35in;left:0.35in;right:0.35in;bottom:0.35in;border:3px solid ${ac};z-index:1;"></div><div style="text-align:center;z-index:2;position:relative;"><div style="width:40px;height:1px;background:${ac};margin:0 auto 24px;"></div><div style="font-size:38px;font-weight:700;text-transform:uppercase;letter-spacing:5px;color:${tx};margin-bottom:18px;padding:0 0.8in;line-height:1.2;">${title}</div><div style="width:40px;height:1px;background:${ac};margin:0 auto 16px;"></div><div style="font-size:15px;font-style:italic;color:${tx}bb;margin-bottom:20px;">${sub}</div>${author ? `<div style="font-family:'Source Code Pro',monospace;font-size:11px;color:${tx}99;margin-bottom:16px;">${author}</div>` : ''}<div style="font-family:'Source Code Pro',monospace;font-size:10px;letter-spacing:3px;color:${tx}88;">${meta}</div></div></div>`;
  } else if (cs === 'geometric') {
    front = `<div style="${fb}padding:1in;">${deco}<div style="position:absolute;top:0;left:0;width:100%;height:100%;z-index:0;overflow:hidden;"><div style="position:absolute;top:18%;left:-10%;width:130%;height:38%;background:${ac};transform:rotate(-30deg);opacity:0.8;"></div></div><div style="position:relative;z-index:1;text-align:left;width:100%;"><div style="font-size:52px;font-weight:700;color:#fff;line-height:1.1;margin-bottom:14px;text-shadow:2px 2px 10px rgba(0,0,0,0.5);">${title}</div><div style="font-size:15px;color:${tx}bb;margin-bottom:16px;">${sub}</div>${author ? `<div style="font-family:'Source Code Pro',monospace;font-size:11px;color:${tx}99;">${author}</div>` : ''}</div><div style="position:absolute;bottom:1in;left:1in;font-family:'Source Code Pro',monospace;font-size:10px;letter-spacing:3px;color:${tx}77;z-index:1;">${meta}</div></div>`;
  } else if (cs === 'bold') {
    front = `<div style="${fb}flex-direction:row;padding:0;"><div style="width:38%;height:100%;background:${ac};display:flex;align-items:flex-end;padding:1in 0.4in;box-sizing:border-box;"><div style="font-family:'Source Code Pro',monospace;font-size:9px;letter-spacing:3px;color:${bg};">${meta}</div></div><div style="width:62%;display:flex;flex-direction:column;justify-content:center;padding:1in 0.7in;"><div style="font-size:44px;font-weight:700;color:#fff;line-height:1.1;margin-bottom:16px;">${title}</div><div style="font-size:15px;color:${ac};font-style:italic;margin-bottom:12px;">${sub}</div>${author ? `<div style="font-family:'Source Code Pro',monospace;font-size:11px;color:${tx}99;">${author}</div>` : ''}</div></div>`;
  } else {
    // classic (default)
    front = `<div style="${fb}text-align:center;padding:1in;">${deco}<div style="position:relative;z-index:1;">${opts.puzzleType ? `<div style="font-family:'Source Code Pro',monospace;font-size:11px;letter-spacing:6px;text-transform:uppercase;color:${ac};margin-bottom:24px;">${opts.puzzleType}</div>` : ''}<div style="width:56px;height:2px;background:${ac};margin:0 auto 32px;"></div><div style="font-size:46px;font-weight:700;color:${ac};line-height:1.15;margin-bottom:18px;padding:0 0.3in;">${title}</div><div style="font-size:16px;font-style:italic;color:${tx}aa;margin-bottom:28px;">${sub}</div><div style="width:56px;height:2px;background:${ac};margin:0 auto 22px;"></div>${author ? `<div style="font-family:'Source Code Pro',monospace;font-size:12px;letter-spacing:2px;color:${tx}99;margin-bottom:16px;">${author}</div>` : ''}<div style="font-family:'Source Code Pro',monospace;font-size:10px;letter-spacing:3px;color:${tx}77;">${meta}</div></div></div>`;
  }

  const coverHtml = `<!DOCTYPE html><html><head><meta charset="UTF-8"><link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,700;1,400&family=Source+Code+Pro:wght@400;600&display=swap" rel="stylesheet"><style>*{margin:0;padding:0;box-sizing:border-box;}@page{size:${fullW.toFixed(4)}in ${fullH.toFixed(4)}in;margin:0;}body{width:${fullW.toFixed(4)}in;height:${fullH.toFixed(4)}in;overflow:hidden;position:relative;background:${bg};print-color-adjust:exact;-webkit-print-color-adjust:exact;}</style></head><body>${back}${spine}${front}</body></html>`;

  return { html: coverHtml, fullW, fullH, spineW };
}

// ══════════════════════════════════════
// PUPPETEER PDF GENERATION
// ══════════════════════════════════════

let browserInstance = null;

async function getBrowser() {
  if (!browserInstance) {
    browserInstance = await puppeteer.launch({
      headless: 'new',
      args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage']
    });
  }
  return browserInstance;
}

async function htmlToPdf(html, width, height) {
  const browser = await getBrowser();
  const page = await browser.newPage();
  await page.setContent(html, { waitUntil: 'networkidle0', timeout: 60000 });
  const pdf = await page.pdf({
    width: width + 'in',
    height: height + 'in',
    printBackground: true,
    preferCSSPageSize: true,
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
  });
  await page.close();
  return pdf;
}

// ══════════════════════════════════════
// WEB UI
// ══════════════════════════════════════

app.get('/', (req, res) => {
  res.send(`<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>KDP Puzzle Engine</title>
<link href="https://fonts.googleapis.com/css2?family=Lora:wght@400;700&family=Source+Code+Pro:wght@400;600&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:#0D0B07;color:#EDE8DC;font-family:Georgia,serif;min-height:100vh;padding:20px}
.w{max-width:660px;margin:0 auto}
h1{font-family:'Courier New',monospace;font-size:10px;letter-spacing:4px;color:#C8951A;text-transform:uppercase}
h2{font-size:22px;margin:4px 0 20px}
.sub{font-family:'Courier New',monospace;font-size:11px;color:#9A9080;margin-bottom:24px}
.c{background:#141108;border:1px solid #2A2518;border-radius:6px;padding:20px 24px;margin-bottom:16px}
.c.gold{border-color:#3A2E10}
label{font-family:'Courier New',monospace;font-size:10px;letter-spacing:3px;text-transform:uppercase;color:#9A9080;display:block;margin:14px 0 6px}
label:first-child{margin-top:0}
input,select,textarea{background:#1A1610;border:1px solid #2A2518;border-radius:4px;padding:8px 12px;font-family:Georgia,serif;font-size:14px;color:#EDE8DC;width:100%;outline:none}
textarea{min-height:70px;resize:vertical}
.r{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.r3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px}
.btn{background:#C8951A;color:#000;border:none;border-radius:4px;padding:14px 32px;cursor:pointer;font-family:'Courier New',monospace;font-size:13px;font-weight:bold;letter-spacing:1px;width:100%;margin-top:16px}
.btn:disabled{opacity:0.4;cursor:not-allowed}
.btn.ghost{background:transparent;color:#C8951A;border:1px solid #C8951A}
.d{font-family:'Source Code Pro',monospace;font-size:11px;color:#C8951A;margin-top:8px}
.info{font-family:'Courier New',monospace;font-size:10px;color:#9A9080;line-height:1.6}
.gold{color:#C8951A}
.ok{color:#3A7A3A}
.wrn{color:#C87A2A}
.shim{height:6px;background:#1A1610;border-radius:4px;overflow:hidden;position:relative;margin-top:8px}
.shim::after{content:'';position:absolute;top:0;left:0;width:40%;height:100%;background:linear-gradient(90deg,transparent,#C8951A44,transparent);animation:s 1.5s infinite}
@keyframes s{0%{transform:translateX(-200%)}100%{transform:translateX(500%)}}
.hide{display:none}
.status{text-align:center;padding:30px 0}
.done{background:#141108;border:1px solid #C8951A;border-radius:6px;padding:24px;text-align:center;margin:16px 0}
</style></head><body>
<div class="w">
<h1>KDP PUZZLE ENGINE</h1>
<h2>Complete Book Generator</h2>
<div class="sub">Generates print-ready Interior PDF + Cover PDF — upload directly to Amazon KDP</div>

<div class="c">
  <label>Book Title</label>
  <input id="title" placeholder="e.g. GRADUATION WORD SEARCH" required>
  <label>Subtitle</label>
  <input id="subtitle" placeholder="e.g. Large Print Puzzle Book for Adults">
  <label>Author Name</label>
  <input id="author" placeholder="e.g. Muhammad">
  <div class="r">
    <div><label>Puzzle Type</label><select id="puzzleType"><option>Word Search</option><option>Sudoku</option></select></div>
    <div><label>Puzzle Count</label><select id="puzzleCount"><option>50</option><option>75</option><option selected>100</option></select></div>
  </div>
  <div class="r3">
    <div><label>Difficulty</label><select id="difficulty"><option>Easy</option><option selected>Medium</option><option>Hard</option></select></div>
    <div><label>Large Print</label><select id="largePrint"><option value="true" selected>Yes (recommended)</option><option value="false">No</option></select></div>
    <div><label>Paper Type</label><select id="paperType"><option value="white">White</option><option value="cream">Cream</option></select></div>
  </div>
</div>

<div class="c gold">
  <label style="color:#C8951A">Cover Settings</label>
  <div class="r">
    <div><label>Colour Theme</label><select id="theme">
      <option value="midnight">Midnight Gold</option><option value="forest">Forest Ink</option>
      <option value="crimson">Crimson Dark</option><option value="ocean">Ocean Depth</option>
      <option value="violet">Violet Night</option><option value="slate">Slate Rust</option>
    </select></div>
    <div><label>Cover Style</label><select id="coverStyle">
      <option value="classic">Classic</option><option value="geometric">Geometric</option>
      <option value="luxury">Luxury</option><option value="bold">Bold</option>
    </select></div>
  </div>
  <label>Back Cover Description</label>
  <textarea id="backDesc" placeholder="Leave blank for auto-generated description"></textarea>
</div>

<div class="c">
  <label>Word List (for Word Search — one word per line, or leave blank for defaults)</label>
  <textarea id="words" placeholder="NURSE&#10;HOSPITAL&#10;MEDICINE&#10;STETHOSCOPE&#10;..." style="min-height:100px"></textarea>
</div>

<div class="d" id="dims"></div>

<button class="btn" id="genBtn" onclick="generate()">Generate Interior PDF + Cover PDF</button>

<div id="loading" class="status hide">
  <div class="info" id="phase">Generating puzzles...</div>
  <div class="shim"></div>
</div>

<div id="result" class="hide">
  <div class="done">
    <div style="font-size:28px;margin-bottom:12px">&#9670;</div>
    <div style="font-family:Georgia;font-size:20px;color:#C8951A;margin-bottom:8px">Book Generated!</div>
    <div class="info" style="margin-bottom:20px">Both PDFs are ready. Download them and upload to KDP.</div>
    <button class="btn" style="margin:8px 0" onclick="downloadInterior()">&#11015; Download Interior PDF</button>
    <button class="btn ghost" style="margin:8px 0" onclick="downloadCover()">&#11015; Download Cover PDF</button>
  </div>
  <div class="c gold" style="margin-top:16px">
    <label style="color:#C8951A">KDP UPLOAD STEPS</label>
    <div class="info">
      <span class="gold">1.</span> Go to kdp.amazon.com &rarr; Create &rarr; Paperback<br>
      <span class="gold">2.</span> Enter title, subtitle, author, keywords<br>
      <span class="gold">3.</span> Check "Low-content book" under Categories<br>
      <span class="gold">4.</span> AI disclosure &rarr; Yes<br>
      <span class="gold">5.</span> Interior: B&W, White paper, 8.5x11, No bleed<br>
      <span class="gold">6.</span> Upload Interior PDF as manuscript<br>
      <span class="gold">7.</span> Upload Cover PDF as "print-ready PDF"<br>
      <span class="gold">8.</span> Price: &pound;7.99 (UK) or $9.99 (US) for 60% royalty<br>
      <span class="gold">9.</span> Publish! Review takes 24-72 hours.
    </div>
  </div>
  <button class="btn ghost" style="margin-top:16px" onclick="reset()">&#8592; Generate Another Book</button>
</div>
</div>

<script>
var interiorBlob=null, coverBlob=null, slug='book';

function updateDims(){
  var pc=parseInt(document.getElementById('puzzleCount').value)||100;
  var aPer=document.getElementById('puzzleType').value==='Word Search'?12:8;
  var totP=3+pc+Math.ceil(pc/aPer);
  var pt=document.getElementById('paperType').value;
  var thick=pt==='cream'?0.0025:0.002252;
  var spine=totP*thick+0.06;
  var fw=0.125+8.5+spine+8.5+0.125;
  document.getElementById('dims').innerHTML='Interior: ~'+totP+' pages | Cover: '+fw.toFixed(3)+' x 11.250 in | Spine: '+spine.toFixed(3)+' in';
}
['puzzleCount','puzzleType','paperType'].forEach(function(id){document.getElementById(id).addEventListener('change',updateDims);});
updateDims();

async function generate(){
  var b=document.getElementById('genBtn');
  b.disabled=true;
  document.getElementById('loading').classList.remove('hide');
  document.getElementById('result').classList.add('hide');

  var wordsRaw=document.getElementById('words').value.trim();
  var words=wordsRaw?wordsRaw.split('\\n').map(function(w){return w.trim().toUpperCase().replace(/[^A-Z]/g,'');}).filter(function(w){return w.length>=4&&w.length<=12;}):[];

  var data={
    title:document.getElementById('title').value||'Puzzle Book',
    subtitle:document.getElementById('subtitle').value,
    author:document.getElementById('author').value,
    puzzleType:document.getElementById('puzzleType').value,
    puzzleCount:document.getElementById('puzzleCount').value,
    difficulty:document.getElementById('difficulty').value,
    largePrint:document.getElementById('largePrint').value==='true',
    paperType:document.getElementById('paperType').value,
    theme:document.getElementById('theme').value,
    coverStyle:document.getElementById('coverStyle').value,
    backDescription:document.getElementById('backDesc').value,
    words:words
  };
  slug=(data.title).toLowerCase().replace(/[^a-z0-9]+/g,'-');

  try{
    document.getElementById('phase').textContent='Generating '+data.puzzleCount+' puzzles... (this may take 30-60 seconds)';
    var res=await fetch('/generate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
    if(!res.ok)throw new Error('Failed: '+res.statusText);
    var json=await res.json();

    document.getElementById('phase').textContent='Rendering interior PDF...';
    var intRes=await fetch('/pdf/interior',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({html:json.interiorHtml,pages:json.totalPages})});
    interiorBlob=await intRes.blob();

    document.getElementById('phase').textContent='Rendering cover PDF...';
    var covRes=await fetch('/pdf/cover',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({html:json.coverHtml,fullW:json.coverDims.fullW,fullH:json.coverDims.fullH})});
    coverBlob=await covRes.blob();

    document.getElementById('loading').classList.add('hide');
    document.getElementById('result').classList.remove('hide');
  }catch(e){
    alert('Error: '+e.message);
    document.getElementById('loading').classList.add('hide');
  }
  b.disabled=false;
}

function downloadInterior(){
  if(!interiorBlob)return;
  var a=document.createElement('a');a.href=URL.createObjectURL(interiorBlob);a.download=slug+'-interior.pdf';a.click();
}
function downloadCover(){
  if(!coverBlob)return;
  var a=document.createElement('a');a.href=URL.createObjectURL(coverBlob);a.download=slug+'-cover.pdf';a.click();
}
function reset(){
  document.getElementById('result').classList.add('hide');
  interiorBlob=null;coverBlob=null;
}
</script></body></html>`);
});

// ── API ROUTES ──
app.post('/generate', (req, res) => {
  try {
    const opts = req.body;
    const interior = buildInteriorHTML(opts);
    const cover = buildCoverHTML(opts, interior.totalPages);
    res.json({
      interiorHtml: interior.html,
      totalPages: interior.totalPages,
      coverHtml: cover.html,
      coverDims: { fullW: cover.fullW, fullH: cover.fullH, spineW: cover.spineW }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/pdf/interior', async (req, res) => {
  try {
    const pdf = await htmlToPdf(req.body.html, 8.5, 11);
    res.set({ 'Content-Type': 'application/pdf', 'Content-Disposition': 'attachment; filename="interior.pdf"' });
    res.send(pdf);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/pdf/cover', async (req, res) => {
  try {
    const pdf = await htmlToPdf(req.body.html, req.body.fullW, req.body.fullH);
    res.set({ 'Content-Type': 'application/pdf', 'Content-Disposition': 'attachment; filename="cover.pdf"' });
    res.send(pdf);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── START ──
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`KDP Engine running → http://localhost:${PORT}`));
