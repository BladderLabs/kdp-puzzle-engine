# KDP Puzzle Engine v5 — Unified Edition

## One tool. Interior PDF + Cover PDF. Ready for Amazon KDP.

### Setup on Replit (5 minutes)

1. Go to **replit.com** → **Create Repl** → choose **Node.js**
2. Delete default files
3. Upload **server.js** and **package.json**
4. In Shell: `npm install`
5. Click **Run**
6. Open the URL Replit gives you

### How It Works

1. Fill in: title, subtitle, author, puzzle type, count, difficulty, theme
2. Optionally paste your own word list (one word per line)
3. Click **Generate Interior PDF + Cover PDF**
4. Wait 30-60 seconds (it's generating 100 puzzles + rendering PDFs)
5. Download both PDFs
6. Upload to KDP: interior as manuscript, cover as "print-ready PDF"

### What It Generates

**Interior PDF:**
- Title page with copyright and AI disclosure
- How to Play page
- Table of Contents
- 50/75/100 puzzle pages (Word Search or Sudoku)
- Answer key with highlighted solutions
- Correct KDP margins (dynamic gutter based on page count)
- B&W, 8.5 x 11 inches, Large Print option

**Cover PDF:**
- Full-wrap: front + spine + back + 0.125" bleed
- Spine width auto-calculated from page count
- Back cover with description and barcode area
- 4 cover styles: Classic, Geometric, Luxury, Bold
- 6 colour themes

### KDP Upload Checklist

- [ ] Create Paperback on kdp.amazon.com
- [ ] Enter title, subtitle, keywords, description
- [ ] Check "Low-content book" under Categories
- [ ] AI disclosure → Yes
- [ ] Interior: B&W, White paper, 8.5x11, No bleed
- [ ] Upload interior PDF as manuscript
- [ ] Upload cover PDF as "print-ready PDF"
- [ ] Price: £7.99 (UK) or $9.99 (US) for 60% royalty
- [ ] Publish → wait 24-72 hours

### Troubleshooting

**Puppeteer won't install:** Try `npm install puppeteer-core` and change
the require line to `require('puppeteer-core')`. Or use a Replit template
that includes Chromium.

**PDF takes too long:** 100 Sudoku puzzles with Hard difficulty takes
longest due to the unique-solution solver. Try Medium or reduce to 50.

**Cover doesn't fit KDP:** Make sure your page count in the form matches
the actual page count of your interior PDF. The spine width depends on it.
